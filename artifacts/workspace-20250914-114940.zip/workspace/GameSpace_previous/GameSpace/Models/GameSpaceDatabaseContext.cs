using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace GameSpace.Models;

public partial class GameSpaceDatabaseContext : DbContext
{
    public GameSpaceDatabaseContext(DbContextOptions<GameSpaceDatabaseContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admins { get; set; }

    public virtual DbSet<BannedWord> BannedWords { get; set; }

    public virtual DbSet<Bookmark> Bookmarks { get; set; }

    public virtual DbSet<ChatMessage> ChatMessages { get; set; }

    public virtual DbSet<DM_Conversations> DM_Conversations { get; set; }

    public virtual DbSet<DM_Messages> DM_Messages { get; set; }

    public virtual DbSet<Coupon> Coupons { get; set; }

    public virtual DbSet<CouponType> CouponTypes { get; set; }

    public virtual DbSet<Evoucher> Evouchers { get; set; }

    public virtual DbSet<EvoucherRedeemLog> EvoucherRedeemLogs { get; set; }

    public virtual DbSet<EvoucherToken> EvoucherTokens { get; set; }

    public virtual DbSet<EvoucherType> EvoucherTypes { get; set; }

    public virtual DbSet<Forum> Forums { get; set; }

    public virtual DbSet<Game> Games { get; set; }

    public virtual DbSet<GameMetricDaily> GameMetricDailies { get; set; }

    public virtual DbSet<GameProductDetail> GameProductDetails { get; set; }

    public virtual DbSet<GameProductDetails> GameProductDetailsNew { get; set; }

    public virtual DbSet<GameSourceMap> GameSourceMaps { get; set; }

    public virtual DbSet<Group> Groups { get; set; }

    public virtual DbSet<Groups> GroupsNew { get; set; }

    public virtual DbSet<GroupBlock> GroupBlocks { get; set; }

    public virtual DbSet<Group_Read_States> GroupReadStates { get; set; }

    public virtual DbSet<GroupChat> GroupChats { get; set; }

    public virtual DbSet<GroupMember> GroupMembers { get; set; }

    public virtual DbSet<LeaderboardSnapshot> LeaderboardSnapshots { get; set; }

    public virtual DbSet<ManagerDatum> ManagerData { get; set; }

    public virtual DbSet<ManagerData> ManagerDataNew { get; set; }

    public virtual DbSet<ManagerRolePermission> ManagerRolePermissions { get; set; }

    public virtual DbSet<MemberSalesProfile> MemberSalesProfiles { get; set; }

    public virtual DbSet<MerchType> MerchTypes { get; set; }

    public virtual DbSet<Metric> Metrics { get; set; }

    public virtual DbSet<MetricSource> MetricSources { get; set; }

    public virtual DbSet<MiniGame> MiniGames { get; set; }

    public virtual DbSet<Mutes> Mutes { get; set; }

    public virtual DbSet<Mutes> MutesNew { get; set; }

    public virtual DbSet<Notifications> Notifications { get; set; }

    public virtual DbSet<Notifications> NotificationsNew { get; set; }

    public virtual DbSet<NotificationAction> NotificationActions { get; set; }

    public virtual DbSet<NotificationRecipient> NotificationRecipients { get; set; }

    public virtual DbSet<NotificationSource> NotificationSources { get; set; }

    public virtual DbSet<OfficialStoreRanking> OfficialStoreRankings { get; set; }

    public virtual DbSet<OrderAddress> OrderAddresses { get; set; }

        public virtual DbSet<OrderAddresses> OrderAddressesNew { get; set; }
        public virtual DbSet<OrderItems> OrderItemsNew { get; set; }
        public virtual DbSet<OtherProductDetails> OtherProductDetailsNew { get; set; }
        public virtual DbSet<PaymentTransactions> PaymentTransactionsNew { get; set; }
        public virtual DbSet<PlayerMarketProductImgs> PlayerMarketProductImgsNew { get; set; }
        public virtual DbSet<ProductImages> ProductImagesNew { get; set; }
        public virtual DbSet<Shipments> ShipmentsNew { get; set; }
        public virtual DbSet<StockMovements> StockMovementsNew { get; set; }
        public virtual DbSet<Support_Ticket_Assignments> SupportTicketAssignmentsNew { get; set; }
        public virtual DbSet<Support_Ticket_Messages> SupportTicketMessagesNew { get; set; }
        public virtual DbSet<Support_Tickets> SupportTicketsNew { get; set; }
        public virtual DbSet<Users> UsersNew { get; set; }
        public virtual DbSet<UserSignInStats> UserSignInStatsNew { get; set; }

    public virtual DbSet<OrderInfo> OrderInfos { get; set; }

    public virtual DbSet<OrderItems> OrderItems { get; set; }

    public virtual DbSet<OrderStatusHistory> OrderStatusHistories { get; set; }

    public virtual DbSet<OtherProductDetail> OtherProductDetails { get; set; }

    public virtual DbSet<PaymentTransaction> PaymentTransactions { get; set; }

    public virtual DbSet<Pet> Pets { get; set; }

    public virtual DbSet<PlayerMarketOrderInfo> PlayerMarketOrderInfos { get; set; }

    public virtual DbSet<PlayerMarketOrderTradepage> PlayerMarketOrderTradepages { get; set; }

    public virtual DbSet<PlayerMarketProductImg> PlayerMarketProductImgs { get; set; }

    public virtual DbSet<PlayerMarketProductInfo> PlayerMarketProductInfos { get; set; }

    public virtual DbSet<PlayerMarketRanking> PlayerMarketRankings { get; set; }

    public virtual DbSet<PlayerMarketTradeMsg> PlayerMarketTradeMsgs { get; set; }

    public virtual DbSet<PopularityIndexDaily> PopularityIndexDailies { get; set; }

    public virtual DbSet<Post> Posts { get; set; }

    public virtual DbSet<PostMetricSnapshot> PostMetricSnapshots { get; set; }

    public virtual DbSet<PostSource> PostSources { get; set; }

    public virtual DbSet<ProductCode> ProductCodes { get; set; }

    public virtual DbSet<ProductImages> ProductImages { get; set; }

    public virtual DbSet<ProductInfo> ProductInfos { get; set; }

    public virtual DbSet<ProductInfoAuditLog> ProductInfoAuditLogs { get; set; }

    public virtual DbSet<Reaction> Reactions { get; set; }

    public virtual DbSet<Relation> Relations { get; set; }

    public virtual DbSet<RelationStatus> RelationStatuses { get; set; }

    public virtual DbSet<Shipments> Shipments { get; set; }

    public virtual DbSet<StockMovement> StockMovements { get; set; }

    public virtual DbSet<Style> Styles { get; set; }

    public virtual DbSet<Supplier> Suppliers { get; set; }

    public virtual DbSet<Thread> Threads { get; set; }

    public virtual DbSet<ThreadPost> ThreadPosts { get; set; }

    public virtual DbSet<Users> Users { get; set; }

    public virtual DbSet<UserIntroduce> UserIntroduces { get; set; }

    public virtual DbSet<UserRight> UserRights { get; set; }

    public virtual DbSet<UserSalesInformation> UserSalesInformations { get; set; }

    public virtual DbSet<UserSignInStat> UserSignInStats { get; set; }

    public virtual DbSet<UserToken> UserTokens { get; set; }

    public virtual DbSet<UserWallet> UserWallets { get; set; }

    public virtual DbSet<WalletHistory> WalletHistories { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Admin>(entity =>
        {
            entity.HasKey(e => e.ManagerId).HasName("PK__Admins__5A6073FC64EF085E");

            entity.Property(e => e.ManagerId)
                .ValueGeneratedNever()
                .HasColumnName("manager_id");
            entity.Property(e => e.LastLogin).HasColumnName("last_login");

            entity.HasOne(d => d.Manager).WithOne(p => p.Admin)
                .HasForeignKey<Admin>(d => d.ManagerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Admins__manager___0E04126B");
        });

        modelBuilder.Entity<BannedWord>(entity =>
        {
            entity.HasKey(e => e.WordId).HasName("PK__banned_w__7FFA1D406FBDDC61");

            entity.ToTable("banned_words");

            entity.Property(e => e.WordId).HasColumnName("word_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Word)
                .HasMaxLength(50)
                .HasColumnName("word");
        });

        modelBuilder.Entity<Bookmark>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__bookmark__3213E83F2689F12E");

            entity.ToTable("bookmarks");

            entity.HasIndex(e => new { e.UserId, e.TargetType, e.TargetId }, "bookmarks_index_20").IsUnique();

            entity.HasIndex(e => new { e.TargetType, e.TargetId }, "bookmarks_index_21");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.TargetId).HasColumnName("target_id");
            entity.Property(e => e.TargetType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("target_type");
            entity.Property(e => e.UserId).HasColumnName("User_ID");

            entity.HasOne(d => d.User).WithMany(p => p.Bookmarks)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__bookmarks__User___6BAEFA67");
        });

        modelBuilder.Entity<ChatMessage>(entity =>
        {
            entity.HasKey(e => e.MessageId).HasName("PK__Chat_Mes__0BBF6EE62FA772B9");

            entity.ToTable("Chat_Message");

            entity.HasIndex(e => e.SentAt, "Chat_Message_index_35");

            entity.HasIndex(e => new { e.ReceiverId, e.SentAt }, "Chat_Message_index_36");

            entity.Property(e => e.MessageId).HasColumnName("message_id");
            entity.Property(e => e.ChatContent)
                .HasMaxLength(255)
                .HasColumnName("chat_content");
            entity.Property(e => e.IsRead).HasColumnName("is_read");
            entity.Property(e => e.IsSent)
                .HasDefaultValue(true)
                .HasColumnName("is_sent");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.ReceiverId).HasColumnName("receiver_id");
            entity.Property(e => e.SenderId).HasColumnName("sender_id");
            entity.Property(e => e.SentAt).HasColumnName("sent_at");

            entity.HasOne(d => d.Manager).WithMany(p => p.ChatMessages)
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK__Chat_Mess__manag__178D7CA5");

            entity.HasOne(d => d.Receiver).WithMany(p => p.ChatMessageReceivers)
                .HasForeignKey(d => d.ReceiverId)
                .HasConstraintName("FK__Chat_Mess__recei__1975C517");

            entity.HasOne(d => d.Sender).WithMany(p => p.ChatMessageSenders)
                .HasForeignKey(d => d.SenderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Chat_Mess__sende__1881A0DE");
        });

        modelBuilder.Entity<Coupon>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Coupon");

            entity.HasIndex(e => new { e.UserId, e.IsUsed, e.CouponId }, "Coupon_index_26");

            entity.Property(e => e.CouponCode)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.CouponId).HasColumnName("CouponID");
            entity.Property(e => e.CouponTypeId).HasColumnName("CouponTypeID");
            entity.Property(e => e.UsedInOrderId).HasColumnName("UsedInOrderID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.UsedInOrder).WithMany()
                .HasForeignKey(d => d.UsedInOrderId)
                .HasConstraintName("FK__Coupon__UsedInOr__6991A7CB");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Coupon__UserID__689D8392");
        });

        modelBuilder.Entity<CouponType>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("CouponType");

            entity.Property(e => e.CouponTypeId).HasColumnName("CouponTypeID");
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.DiscountType).HasMaxLength(10);
            entity.Property(e => e.DiscountValue).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.MinSpend).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<Evoucher>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("EVoucher");

            entity.HasIndex(e => new { e.UserId, e.IsUsed, e.EvoucherId }, "EVoucher_index_27");

            entity.Property(e => e.EvoucherCode)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("EVoucherCode");
            entity.Property(e => e.EvoucherId).HasColumnName("EVoucherID");
            entity.Property(e => e.EvoucherTypeId).HasColumnName("EVoucherTypeID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__EVoucher__UserID__6B79F03D");
        });

        modelBuilder.Entity<EvoucherRedeemLog>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("EVoucherRedeemLog");

            entity.HasIndex(e => new { e.EvoucherId, e.ScannedAt }, "EVoucherRedeemLog_index_28");

            entity.HasIndex(e => new { e.UserId, e.ScannedAt }, "EVoucherRedeemLog_index_29");

            entity.Property(e => e.EvoucherId).HasColumnName("EVoucherID");
            entity.Property(e => e.RedeemId).HasColumnName("RedeemID");
            entity.Property(e => e.Status).HasMaxLength(20);
            entity.Property(e => e.TokenId).HasColumnName("TokenID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__EVoucherR__UserI__61F08603");
        });

        modelBuilder.Entity<EvoucherToken>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("EVoucherToken");

            entity.Property(e => e.EvoucherId).HasColumnName("EVoucherID");
            entity.Property(e => e.Token)
                .HasMaxLength(64)
                .IsUnicode(false);
            entity.Property(e => e.TokenId).HasColumnName("TokenID");
        });

        modelBuilder.Entity<EvoucherType>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("EVoucherType");

            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.EvoucherTypeId).HasColumnName("EVoucherTypeID");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.ValueAmount).HasColumnType("decimal(10, 2)");
        });

        modelBuilder.Entity<Forum>(entity =>
        {
            entity.HasKey(e => e.ForumId).HasName("PK__forums__69A2FA58CFFF3479");

            entity.ToTable("forums");

            entity.HasIndex(e => e.GameId, "forums_index_15").IsUnique();

            entity.Property(e => e.ForumId).HasColumnName("forum_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Description)
                .HasMaxLength(300)
                .HasColumnName("description");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");

            entity.HasOne(d => d.Game).WithOne(p => p.Forum)
                .HasForeignKey<Forum>(d => d.GameId)
                .HasConstraintName("FK__forums__game_id__6501FCD8");
        });

        modelBuilder.Entity<Game>(entity =>
        {
            entity.HasKey(e => e.GameId).HasName("PK__games__FFE11FCFDAD0C969");

            entity.ToTable("games");

            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("created_at");
            entity.Property(e => e.Genre)
                .HasMaxLength(50)
                .HasColumnName("genre");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
            entity.Property(e => e.NameZh)
                .HasMaxLength(100)
                .HasColumnName("name_zh");
        });

        modelBuilder.Entity<GameMetricDaily>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__game_met__3213E83F3E2670CA");

            entity.ToTable("game_metric_daily");

            entity.HasIndex(e => new { e.GameId, e.MetricId, e.Date }, "game_metric_daily_index_3").IsUnique();

            entity.HasIndex(e => new { e.Date, e.MetricId }, "game_metric_daily_index_4");

            entity.HasIndex(e => new { e.GameId, e.Date }, "game_metric_daily_index_5");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AggMethod)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("agg_method");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.MetricId).HasColumnName("metric_id");
            entity.Property(e => e.Quality)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("quality");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.Value)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("value");

            entity.HasOne(d => d.Game).WithMany(p => p.GameMetricDailies)
                .HasForeignKey(d => d.GameId)
                .HasConstraintName("FK__game_metr__game___09FE775D");

            entity.HasOne(d => d.Metric).WithMany(p => p.GameMetricDailies)
                .HasForeignKey(d => d.MetricId)
                .HasConstraintName("FK__game_metr__metri__0AF29B96");
        });

        modelBuilder.Entity<GameProductDetail>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.DownloadLink)
                .HasMaxLength(500)
                .HasColumnName("download_link");
            entity.Property(e => e.GameType)
                .HasMaxLength(200)
                .HasColumnName("game_type");
            entity.Property(e => e.PlatformId).HasColumnName("platform_id");
            entity.Property(e => e.PlatformName)
                .HasMaxLength(100)
                .HasColumnName("platform_name");
            entity.Property(e => e.ProductDescription).HasColumnName("product_description");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ProductName)
                .HasMaxLength(200)
                .HasColumnName("product_name");
            entity.Property(e => e.SupplierId).HasColumnName("supplier_id");
        });

        modelBuilder.Entity<GameSourceMap>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__game_sou__3213E83F28A4459D");

            entity.ToTable("game_source_map");

            entity.HasIndex(e => new { e.GameId, e.SourceId }, "game_source_map_index_1").IsUnique();

            entity.HasIndex(e => new { e.SourceId, e.ExternalKey }, "game_source_map_index_2");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.ExternalKey)
                .HasMaxLength(255)
                .HasColumnName("external_key");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.SourceId).HasColumnName("source_id");

            entity.HasOne(d => d.Game).WithMany(p => p.GameSourceMaps)
                .HasForeignKey(d => d.GameId)
                .HasConstraintName("FK__game_sour__game___08162EEB");

            entity.HasOne(d => d.Source).WithMany(p => p.GameSourceMaps)
                .HasForeignKey(d => d.SourceId)
                .HasConstraintName("FK__game_sour__sourc__090A5324");
        });

        modelBuilder.Entity<Group>(entity =>
        {
            entity.HasKey(e => e.GroupId).HasName("PK__Groups__D57795A04E6A602C");

            entity.Property(e => e.GroupId).HasColumnName("group_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.GroupName)
                .HasMaxLength(10)
                .HasColumnName("group_name");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.Groups)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("FK__Groups__created___1A69E950");
        });

        modelBuilder.Entity<GroupBlock>(entity =>
        {
            entity.HasKey(e => e.BlockId).HasName("PK__Group_Bl__A67E647D7FFDE20E");

            entity.ToTable("Group_Block");

            entity.HasIndex(e => new { e.GroupId, e.UserId }, "Group_Block_index_39").IsUnique();

            entity.HasIndex(e => e.GroupId, "Group_Block_index_40");

            entity.HasIndex(e => e.UserId, "Group_Block_index_41");

            entity.Property(e => e.BlockId).HasColumnName("block_id");
            entity.Property(e => e.BlockedBy).HasColumnName("blocked_by");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.GroupId).HasColumnName("group_id");
            entity.Property(e => e.UserId).HasColumnName("User_ID");

            entity.HasOne(d => d.BlockedByNavigation).WithMany(p => p.GroupBlockBlockedByNavigations)
                .HasForeignKey(d => d.BlockedBy)
                .HasConstraintName("FK__Group_Blo__block__2116E6DF");

            entity.HasOne(d => d.Group).WithMany(p => p.GroupBlocks)
                .HasForeignKey(d => d.GroupId)
                .HasConstraintName("FK__Group_Blo__group__1F2E9E6D");

            entity.HasOne(d => d.User).WithMany(p => p.GroupBlockUsers)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__Group_Blo__User___2022C2A6");
        });

        modelBuilder.Entity<GroupChat>(entity =>
        {
            entity.HasKey(e => e.GroupChatId).HasName("PK__Group_Ch__C4565A19CEDFBF18");

            entity.ToTable("Group_Chat");

            entity.HasIndex(e => e.GroupId, "Group_Chat_index_37");

            entity.HasIndex(e => new { e.GroupId, e.SentAt }, "Group_Chat_index_38");

            entity.Property(e => e.GroupChatId).HasColumnName("group_chat_id");
            entity.Property(e => e.GroupChatContent)
                .HasMaxLength(255)
                .HasColumnName("group_chat_content");
            entity.Property(e => e.GroupId).HasColumnName("group_id");
            entity.Property(e => e.IsSent)
                .HasDefaultValue(true)
                .HasColumnName("is_sent");
            entity.Property(e => e.SenderId).HasColumnName("sender_id");
            entity.Property(e => e.SentAt).HasColumnName("sent_at");

            entity.HasOne(d => d.Group).WithMany(p => p.GroupChats)
                .HasForeignKey(d => d.GroupId)
                .HasConstraintName("FK__Group_Cha__group__1D4655FB");

            entity.HasOne(d => d.Sender).WithMany(p => p.GroupChats)
                .HasForeignKey(d => d.SenderId)
                .HasConstraintName("FK__Group_Cha__sende__1E3A7A34");
        });

        modelBuilder.Entity<GroupMember>(entity =>
        {
            entity.HasKey(e => new { e.GroupId, e.UserId }).HasName("PK__Group_Me__C7714CB9F56F94CE");

            entity.ToTable("Group_Member");

            entity.Property(e => e.GroupId).HasColumnName("group_id");
            entity.Property(e => e.UserId).HasColumnName("User_ID");
            entity.Property(e => e.IsAdmin).HasColumnName("is_admin");
            entity.Property(e => e.JoinedAt).HasColumnName("joined_at");

            entity.HasOne(d => d.Group).WithMany(p => p.GroupMembers)
                .HasForeignKey(d => d.GroupId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Group_Mem__group__1B5E0D89");

            entity.HasOne(d => d.User).WithMany(p => p.GroupMembers)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Group_Mem__User___1C5231C2");
        });

        modelBuilder.Entity<LeaderboardSnapshot>(entity =>
        {
            entity.HasKey(e => e.SnapshotId).HasName("PK__leaderbo__C27CFBF749AA0C32");

            entity.ToTable("leaderboard_snapshots");

            entity.HasIndex(e => new { e.Period, e.Ts, e.GameId }, "leaderboard_snapshots_index_10");

            entity.HasIndex(e => new { e.Period, e.Ts, e.Rank }, "leaderboard_snapshots_index_8");

            entity.HasIndex(e => new { e.Period, e.Ts, e.Rank, e.GameId }, "leaderboard_snapshots_index_9").IsUnique();

            entity.Property(e => e.SnapshotId).HasColumnName("snapshot_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.IndexValue)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("index_value");
            entity.Property(e => e.Period)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("period");
            entity.Property(e => e.Rank).HasColumnName("rank");
            entity.Property(e => e.Ts).HasColumnName("ts");

            entity.HasOne(d => d.Game).WithMany(p => p.LeaderboardSnapshots)
                .HasForeignKey(d => d.GameId)
                .HasConstraintName("FK__leaderboa__game___062DE679");
        });

        modelBuilder.Entity<ManagerDatum>(entity =>
        {
            entity.HasKey(e => e.ManagerId).HasName("PK__ManagerD__AE5FEFAD638D88FF");

            entity.HasIndex(e => e.ManagerEmail, "UQ__ManagerD__0890969EC9C76047").IsUnique();

            entity.HasIndex(e => e.ManagerAccount, "UQ__ManagerD__62B5E21119A93877").IsUnique();

            entity.Property(e => e.ManagerId)
                .ValueGeneratedNever()
                .HasColumnName("Manager_Id");
            entity.Property(e => e.AdministratorRegistrationDate).HasColumnName("Administrator_registration_date");
            entity.Property(e => e.ManagerAccessFailedCount).HasColumnName("Manager_AccessFailedCount");
            entity.Property(e => e.ManagerAccount)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("Manager_Account");
            entity.Property(e => e.ManagerEmail)
                .HasMaxLength(255)
                .HasColumnName("Manager_Email");
            entity.Property(e => e.ManagerEmailConfirmed).HasColumnName("Manager_EmailConfirmed");
            entity.Property(e => e.ManagerLockoutEnabled)
                .HasDefaultValue(true)
                .HasColumnName("Manager_LockoutEnabled");
            entity.Property(e => e.ManagerLockoutEnd).HasColumnName("Manager_LockoutEnd");
            entity.Property(e => e.ManagerName)
                .HasMaxLength(30)
                .HasColumnName("Manager_Name");
            entity.Property(e => e.ManagerPassword)
                .HasMaxLength(200)
                .HasColumnName("Manager_Password");

            entity.HasMany(d => d.ManagerRoles).WithMany(p => p.Managers)
                .UsingEntity<Dictionary<string, object>>(
                    "ManagerRole",
                    r => r.HasOne<ManagerRolePermission>().WithMany()
                        .HasForeignKey("ManagerRoleId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ManagerRo__Manag__0CDAE408"),
                    l => l.HasOne<ManagerDatum>().WithMany()
                        .HasForeignKey("ManagerId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ManagerRo__Manag__0BE6BFCF"),
                    j =>
                    {
                        j.HasKey("ManagerId", "ManagerRoleId").HasName("PK__ManagerR__6270897EA52FCCCF");
                        j.ToTable("ManagerRole");
                        j.IndexerProperty<int>("ManagerId").HasColumnName("Manager_Id");
                        j.IndexerProperty<int>("ManagerRoleId").HasColumnName("ManagerRole_Id");
                    });
        });

        modelBuilder.Entity<ManagerRolePermission>(entity =>
        {
            entity.HasKey(e => e.ManagerRoleId).HasName("PK__ManagerR__C2F66D3DC40C7408");

            entity.ToTable("ManagerRolePermission");

            entity.Property(e => e.ManagerRoleId)
                .ValueGeneratedNever()
                .HasColumnName("ManagerRole_Id");
            entity.Property(e => e.CustomerService).HasColumnName("customer_service");
            entity.Property(e => e.PetRightsManagement).HasColumnName("Pet_Rights_Management");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .HasColumnName("role_name");
        });

        modelBuilder.Entity<MemberSalesProfile>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__MemberSa__206D9170B9BF5CEA");

            entity.ToTable("MemberSalesProfile");

            entity.Property(e => e.UserId)
                .ValueGeneratedNever()
                .HasColumnName("User_Id");
            entity.Property(e => e.BankAccountNumber)
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.HasOne(d => d.User).WithOne(p => p.MemberSalesProfile)
                .HasForeignKey<MemberSalesProfile>(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__MemberSal__User___119F9925");
        });

        modelBuilder.Entity<MerchType>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("MerchType");

            entity.Property(e => e.MerchTypeId)
                .ValueGeneratedOnAdd()
                .HasColumnName("merch_type_id");
            entity.Property(e => e.MerchTypeName)
                .HasMaxLength(50)
                .HasColumnName("merch_type_name");
        });

        modelBuilder.Entity<Metric>(entity =>
        {
            entity.HasKey(e => e.MetricId).HasName("PK__metrics__13D5DCA4360F643C");

            entity.ToTable("metrics");

            entity.HasIndex(e => new { e.SourceId, e.Code }, "metrics_index_0").IsUnique();

            entity.Property(e => e.MetricId).HasColumnName("metric_id");
            entity.Property(e => e.Code)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("code");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .HasColumnName("description");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.SourceId).HasColumnName("source_id");
            entity.Property(e => e.Unit)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("unit");

            entity.HasOne(d => d.Source).WithMany(p => p.Metrics)
                .HasForeignKey(d => d.SourceId)
                .HasConstraintName("FK__metrics__source___0DCF0841");
        });

        modelBuilder.Entity<MetricSource>(entity =>
        {
            entity.HasKey(e => e.SourceId).HasName("PK__metric_s__3035A9B60C38D610");

            entity.ToTable("metric_sources");

            entity.Property(e => e.SourceId).HasColumnName("source_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
            entity.Property(e => e.Note)
                .HasMaxLength(50)
                .HasColumnName("note");
        });

        modelBuilder.Entity<MiniGame>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("MiniGame");

            entity.HasIndex(e => new { e.UserId, e.StartTime }, "MiniGame_index_24");

            entity.HasIndex(e => new { e.PetId, e.StartTime }, "MiniGame_index_25");

            entity.Property(e => e.CouponGained)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PetId).HasColumnName("PetID");
            entity.Property(e => e.PlayId).HasColumnName("PlayID");
            entity.Property(e => e.Result).HasMaxLength(10);
            entity.Property(e => e.SpeedMultiplier).HasColumnType("decimal(5, 2)");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__MiniGame__UserID__6F7F8B4B");
        });

        modelBuilder.Entity<Mute>(entity =>
        {
            entity.HasKey(e => e.MuteId).HasName("PK__Mutes__84EE96EB9DD35443");

            entity.Property(e => e.MuteId).HasColumnName("mute_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.IsActive)
                .HasDefaultValue(true)
                .HasColumnName("is_active");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.MuteName)
                .HasMaxLength(10)
                .HasColumnName("mute_name");

            entity.HasOne(d => d.Manager).WithMany(p => p.Mutes)
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK__Mutes__manager_i__0EF836A4");
        });

        modelBuilder.Entity<Notification>(entity =>
        {
            entity.HasKey(e => e.NotificationId).HasName("PK__Notifica__E059842FEBC56A47");

            entity.Property(e => e.NotificationId).HasColumnName("notification_id");
            entity.Property(e => e.ActionId).HasColumnName("action_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.GroupId).HasColumnName("group_id");
            entity.Property(e => e.NotificationMessage)
                .HasMaxLength(255)
                .HasColumnName("notification_message");
            entity.Property(e => e.NotificationTitle)
                .HasMaxLength(20)
                .HasColumnName("notification_title");
            entity.Property(e => e.SenderId).HasColumnName("sender_id");
            entity.Property(e => e.SenderManagerId).HasColumnName("sender_manager_id");
            entity.Property(e => e.SourceId).HasColumnName("source_id");

            entity.HasOne(d => d.Action).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.ActionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Notificat__actio__11D4A34F");

            entity.HasOne(d => d.Group).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.GroupId)
                .HasConstraintName("FK__Notificat__group__14B10FFA");

            entity.HasOne(d => d.Sender).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.SenderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Notificat__sende__12C8C788");

            entity.HasOne(d => d.SenderManager).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.SenderManagerId)
                .HasConstraintName("FK__Notificat__sende__13BCEBC1");

            entity.HasOne(d => d.Source).WithMany(p => p.Notifications)
                .HasForeignKey(d => d.SourceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Notificat__sourc__10E07F16");
        });

        modelBuilder.Entity<NotificationAction>(entity =>
        {
            entity.HasKey(e => e.ActionId).HasName("PK__Notifica__74EFC2176383B96B");

            entity.ToTable("Notification_Actions");

            entity.HasIndex(e => e.ActionName, "Notification_Actions_index_32").IsUnique();

            entity.Property(e => e.ActionId).HasColumnName("action_id");
            entity.Property(e => e.ActionName)
                .HasMaxLength(10)
                .HasColumnName("action_name");
        });

        modelBuilder.Entity<NotificationRecipient>(entity =>
        {
            entity.HasKey(e => e.RecipientId).HasName("PK__Notifica__FA0A4027FE384C6D");

            entity.ToTable("Notification_Recipients");

            entity.HasIndex(e => new { e.UserId, e.IsRead, e.RecipientId }, "IX_Inbox");

            entity.HasIndex(e => new { e.NotificationId, e.UserId }, "Notification_Recipients_index_33").IsUnique();

            entity.Property(e => e.RecipientId).HasColumnName("recipient_id");
            entity.Property(e => e.IsRead).HasColumnName("is_read");
            entity.Property(e => e.NotificationId).HasColumnName("notification_id");
            entity.Property(e => e.ReadAt).HasColumnName("read_at");
            entity.Property(e => e.UserId).HasColumnName("User_ID");

            entity.HasOne(d => d.Notification).WithMany(p => p.NotificationRecipients)
                .HasForeignKey(d => d.NotificationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Notificat__notif__15A53433");

            entity.HasOne(d => d.User).WithMany(p => p.NotificationRecipients)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Notificat__User___1699586C");
        });

        modelBuilder.Entity<NotificationSource>(entity =>
        {
            entity.HasKey(e => e.SourceId).HasName("PK__Notifica__3035A9B6AB2C5CDE");

            entity.ToTable("Notification_Sources");

            entity.Property(e => e.SourceId).HasColumnName("source_id");
            entity.Property(e => e.SourceName)
                .HasMaxLength(10)
                .HasColumnName("source_name");
        });

        modelBuilder.Entity<OfficialStoreRanking>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Official_Store_Ranking");

            entity.Property(e => e.PeriodType)
                .HasMaxLength(20)
                .HasColumnName("period_type");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.RankingDate).HasColumnName("ranking_date");
            entity.Property(e => e.RankingId)
                .ValueGeneratedOnAdd()
                .HasColumnName("ranking_id");
            entity.Property(e => e.RankingMetric)
                .HasMaxLength(50)
                .HasColumnName("ranking_metric");
            entity.Property(e => e.RankingPosition).HasColumnName("ranking_position");
            entity.Property(e => e.RankingUpdatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("ranking_updated_at");
            entity.Property(e => e.TradingAmount)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("trading_amount");
            entity.Property(e => e.TradingVolume).HasColumnName("trading_volume");
        });

        modelBuilder.Entity<OrderAddress>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK__OrderAdd__465962297AF1A4A5");

            entity.Property(e => e.OrderId)
                .ValueGeneratedNever()
                .HasColumnName("order_id");
            entity.Property(e => e.Address1)
                .HasMaxLength(200)
                .HasColumnName("address1");
            entity.Property(e => e.Address2)
                .HasMaxLength(200)
                .HasColumnName("address2");
            entity.Property(e => e.City)
                .HasMaxLength(50)
                .HasColumnName("city");
            entity.Property(e => e.Country)
                .HasMaxLength(30)
                .HasColumnName("country");
            entity.Property(e => e.Phone)
                .HasMaxLength(30)
                .HasColumnName("phone");
            entity.Property(e => e.Recipient)
                .HasMaxLength(100)
                .HasColumnName("recipient");
            entity.Property(e => e.Zipcode)
                .HasMaxLength(10)
                .HasColumnName("zipcode");
        });

        modelBuilder.Entity<OrderInfo>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK__OrderInf__46596229C3B9E39E");

            entity.ToTable("OrderInfo");

            entity.HasIndex(e => new { e.OrderDate, e.OrderCode }, "IX_OrderInfo_OrderDate_OrderCode");

            entity.HasIndex(e => new { e.PaymentStatus, e.OrderDate }, "IX_OrderInfo_PaymentStatus");

            entity.HasIndex(e => new { e.OrderStatus, e.OrderDate }, "IX_OrderInfo_Status_Date");

            entity.HasIndex(e => new { e.UserId, e.OrderDate }, "IX_OrderInfo_User_Date");

            entity.HasIndex(e => e.OrderCode, "UQ_OrderInfo_OrderCode").IsUnique();

            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.CompletedAt).HasColumnName("completed_at");
            entity.Property(e => e.OrderCode)
                .HasDefaultValueSql("(NEXT VALUE FOR [dbo].[SeqOrderCode])")
                .HasColumnName("order_code");
            entity.Property(e => e.OrderDate)
                .HasDefaultValueSql("(sysutcdatetime())")
                .HasColumnName("order_date");
            entity.Property(e => e.OrderStatus)
                .HasMaxLength(30)
                .HasDefaultValue("未出貨")
                .HasColumnName("order_status");
            entity.Property(e => e.OrderTotal)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("order_total");
            entity.Property(e => e.PaymentAt).HasColumnName("payment_at");
            entity.Property(e => e.PaymentStatus)
                .HasMaxLength(30)
                .HasDefaultValue("未付款")
                .HasColumnName("payment_status");
            entity.Property(e => e.ShippedAt).HasColumnName("shipped_at");
            entity.Property(e => e.UserId).HasColumnName("User_ID");
        });

        modelBuilder.Entity<OrderItem>(entity =>
        {
            entity.HasKey(e => e.ItemId).HasName("PK__OrderIte__52020FDD2D390A7A");

            entity.Property(e => e.ItemId).HasColumnName("item_id");
            entity.Property(e => e.LineNo).HasColumnName("line_no");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.Subtotal)
                .HasComputedColumnSql("(CONVERT([decimal](18,2),[unit_price]*[quantity]))", true)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("subtotal");
            entity.Property(e => e.UnitPrice)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("unit_price");

            entity.HasOne(d => d.Order).WithMany(p => p.OrderItems)
                .HasForeignKey(d => d.OrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__OrderItem__order__5A4F643B");
        });

        modelBuilder.Entity<OrderStatusHistory>(entity =>
        {
            entity.HasKey(e => e.HistoryId).HasName("PK__OrderSta__096AA2E9A89BA70E");

            entity.ToTable("OrderStatusHistory");

            entity.Property(e => e.HistoryId).HasColumnName("history_id");
            entity.Property(e => e.ChangedAt)
                .HasDefaultValueSql("(sysutcdatetime())")
                .HasColumnName("changed_at");
            entity.Property(e => e.ChangedBy).HasColumnName("changed_by");
            entity.Property(e => e.FromStatus)
                .HasMaxLength(30)
                .HasColumnName("from_status");
            entity.Property(e => e.Note)
                .HasMaxLength(200)
                .HasColumnName("note");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.ToStatus)
                .HasMaxLength(30)
                .HasColumnName("to_status");
        });

        modelBuilder.Entity<OtherProductDetail>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.Color)
                .HasMaxLength(50)
                .HasColumnName("color");
            entity.Property(e => e.DigitalCode)
                .HasMaxLength(100)
                .HasColumnName("digital_code");
            entity.Property(e => e.Dimensions)
                .HasMaxLength(100)
                .HasColumnName("dimensions");
            entity.Property(e => e.Material)
                .HasMaxLength(50)
                .HasColumnName("material");
            entity.Property(e => e.MerchTypeId).HasColumnName("merch_type_id");
            entity.Property(e => e.ProductDescription).HasColumnName("product_description");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ProductName)
                .HasMaxLength(200)
                .HasColumnName("product_name");
            entity.Property(e => e.Size)
                .HasMaxLength(50)
                .HasColumnName("size");
            entity.Property(e => e.StockQuantity).HasColumnName("stock_quantity");
            entity.Property(e => e.SupplierId).HasColumnName("supplier_id");
            entity.Property(e => e.Weight)
                .HasMaxLength(50)
                .HasColumnName("weight");
        });

        modelBuilder.Entity<PaymentTransaction>(entity =>
        {
            entity.HasKey(e => e.PaymentId).HasName("PK__PaymentT__ED1FC9EA68A49FF1");

            entity.Property(e => e.PaymentId).HasColumnName("payment_id");
            entity.Property(e => e.Amount)
                .HasColumnType("decimal(18, 2)")
                .HasColumnName("amount");
            entity.Property(e => e.ConfirmedAt).HasColumnName("confirmed_at");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(sysutcdatetime())")
                .HasColumnName("created_at");
            entity.Property(e => e.Meta).HasColumnName("meta");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.PaymentCode)
                .HasDefaultValueSql("(NEXT VALUE FOR [dbo].[SeqPaymentCode])")
                .HasColumnName("payment_code");
            entity.Property(e => e.Provider)
                .HasMaxLength(50)
                .HasColumnName("provider");
            entity.Property(e => e.ProviderTxn)
                .HasMaxLength(100)
                .HasColumnName("provider_txn");
            entity.Property(e => e.Status)
                .HasMaxLength(30)
                .HasColumnName("status");
            entity.Property(e => e.TxnType)
                .HasMaxLength(30)
                .HasColumnName("txn_type");
        });

        modelBuilder.Entity<Pet>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Pet");

            entity.HasIndex(e => e.UserId, "Pet_index_23");

            entity.Property(e => e.BackgroundColor).HasMaxLength(50);
            entity.Property(e => e.PetId).HasColumnName("PetID");
            entity.Property(e => e.PetName).HasMaxLength(50);
            entity.Property(e => e.PointsChangedBackgroundColor).HasColumnName("PointsChanged_BackgroundColor");
            entity.Property(e => e.PointsChangedSkinColor).HasColumnName("PointsChanged_SkinColor");
            entity.Property(e => e.PointsGainedLevelUp).HasColumnName("PointsGained_LevelUp");
            entity.Property(e => e.PointsGainedTimeLevelUp).HasColumnName("PointsGainedTime_LevelUp");
            entity.Property(e => e.SkinColor)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Pet__UserID__6E8B6712");
        });

        modelBuilder.Entity<PlayerMarketOrderInfo>(entity =>
        {
            entity.HasKey(e => e.POrderId).HasName("PK__PlayerMa__AACAAD70C933BAFC");

            entity.ToTable("PlayerMarketOrderInfo");

            entity.Property(e => e.POrderId)
                .ValueGeneratedNever()
                .HasColumnName("p_order_id");
            entity.Property(e => e.BuyerId).HasColumnName("buyer_id");
            entity.Property(e => e.POrderCreatedAt).HasColumnName("p_order_created_at");
            entity.Property(e => e.POrderDate).HasColumnName("p_order_date");
            entity.Property(e => e.POrderStatus)
                .HasMaxLength(1)
                .HasColumnName("p_order_status");
            entity.Property(e => e.POrderTotal).HasColumnName("p_order_total");
            entity.Property(e => e.POrderUpdatedAt).HasColumnName("p_order_updated_at");
            entity.Property(e => e.PPaymentStatus)
                .HasMaxLength(1)
                .HasColumnName("p_payment_status");
            entity.Property(e => e.PProductId).HasColumnName("p_product_id");
            entity.Property(e => e.PQuantity).HasColumnName("p_quantity");
            entity.Property(e => e.PUnitPrice).HasColumnName("p_unit_price");
            entity.Property(e => e.SellerId).HasColumnName("seller_id");

            entity.HasOne(d => d.Buyer).WithMany(p => p.PlayerMarketOrderInfoBuyers)
                .HasForeignKey(d => d.BuyerId)
                .HasConstraintName("FK__PlayerMar__buyer__0A338187");

            entity.HasOne(d => d.PProduct).WithMany(p => p.PlayerMarketOrderInfos)
                .HasForeignKey(d => d.PProductId)
                .HasConstraintName("FK__PlayerMar__p_pro__084B3915");

            entity.HasOne(d => d.Seller).WithMany(p => p.PlayerMarketOrderInfoSellers)
                .HasForeignKey(d => d.SellerId)
                .HasConstraintName("FK__PlayerMar__selle__093F5D4E");
        });

        modelBuilder.Entity<PlayerMarketOrderTradepage>(entity =>
        {
            entity.HasKey(e => e.POrderTradepageId).HasName("PK__PlayerMa__4E2C726D362DA57F");

            entity.ToTable("PlayerMarketOrderTradepage");

            entity.Property(e => e.POrderTradepageId)
                .ValueGeneratedNever()
                .HasColumnName("p_order_tradepage_id");
            entity.Property(e => e.BuyerReceivedAt).HasColumnName("buyer_received_at");
            entity.Property(e => e.CompletedAt).HasColumnName("completed_at");
            entity.Property(e => e.POrderId).HasColumnName("p_order_id");
            entity.Property(e => e.POrderPlatformFee).HasColumnName("p_order_platform_fee");
            entity.Property(e => e.PProductId).HasColumnName("p_product_id");
            entity.Property(e => e.SellerTransferredAt).HasColumnName("seller_transferred_at");

            entity.HasOne(d => d.POrder).WithMany(p => p.PlayerMarketOrderTradepages)
                .HasForeignKey(d => d.POrderId)
                .HasConstraintName("FK__PlayerMar__p_ord__0B27A5C0");

            entity.HasOne(d => d.PProduct).WithMany(p => p.PlayerMarketOrderTradepages)
                .HasForeignKey(d => d.PProductId)
                .HasConstraintName("FK__PlayerMar__p_pro__0C1BC9F9");
        });

        modelBuilder.Entity<PlayerMarketProductImg>(entity =>
        {
            entity.HasKey(e => e.PProductImgId).HasName("PK__PlayerMa__75AAE6F0C6CBADFB");

            entity.Property(e => e.PProductImgId)
                .ValueGeneratedNever()
                .HasColumnName("p_product_img_id");
            entity.Property(e => e.PProductId).HasColumnName("p_product_id");
            entity.Property(e => e.PProductImgUrl).HasColumnName("p_product_img_url");

            entity.HasOne(d => d.PProduct).WithMany(p => p.PlayerMarketProductImgs)
                .HasForeignKey(d => d.PProductId)
                .HasConstraintName("FK__PlayerMar__p_pro__075714DC");
        });

        modelBuilder.Entity<PlayerMarketProductInfo>(entity =>
        {
            entity.HasKey(e => e.PProductId).HasName("PK__PlayerMa__A33C81652AD0DD1E");

            entity.ToTable("PlayerMarketProductInfo");

            entity.Property(e => e.PProductId)
                .ValueGeneratedNever()
                .HasColumnName("p_product_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.PProductDescription)
                .HasMaxLength(1)
                .HasColumnName("p_product_description");
            entity.Property(e => e.PProductImgId)
                .HasMaxLength(1)
                .HasColumnName("p_product_img_id");
            entity.Property(e => e.PProductName)
                .HasMaxLength(1)
                .HasColumnName("p_product_name");
            entity.Property(e => e.PProductTitle)
                .HasMaxLength(1)
                .HasColumnName("p_product_title");
            entity.Property(e => e.PProductType)
                .HasMaxLength(1)
                .HasColumnName("p_product_type");
            entity.Property(e => e.PStatus)
                .HasMaxLength(1)
                .HasColumnName("p_status");
            entity.Property(e => e.Price)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("price");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.SellerId).HasColumnName("seller_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");

            entity.HasOne(d => d.Seller).WithMany(p => p.PlayerMarketProductInfos)
                .HasForeignKey(d => d.SellerId)
                .HasConstraintName("FK__PlayerMar__selle__0662F0A3");
        });

        modelBuilder.Entity<PlayerMarketRanking>(entity =>
        {
            entity.HasKey(e => e.PRankingId).HasName("PK__PlayerMa__2B50ED32026B4213");

            entity.ToTable("PlayerMarketRanking");

            entity.Property(e => e.PRankingId)
                .ValueGeneratedNever()
                .HasColumnName("p_ranking_id");
            entity.Property(e => e.PPeriodType)
                .HasMaxLength(255)
                .HasColumnName("p_period_type");
            entity.Property(e => e.PProductId).HasColumnName("p_product_id");
            entity.Property(e => e.PRankingDate).HasColumnName("p_ranking_date");
            entity.Property(e => e.PRankingMetric)
                .HasMaxLength(255)
                .HasColumnName("p_ranking_metric");
            entity.Property(e => e.PRankingPosition).HasColumnName("p_ranking_position");
            entity.Property(e => e.PTradingAmount)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("p_trading_amount");
            entity.Property(e => e.PTradingVolume).HasColumnName("p_trading_volume");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");

            entity.HasOne(d => d.PProduct).WithMany(p => p.PlayerMarketRankings)
                .HasForeignKey(d => d.PProductId)
                .HasConstraintName("FK__PlayerMar__p_pro__047AA831");
        });

        modelBuilder.Entity<PlayerMarketTradeMsg>(entity =>
        {
            entity.HasKey(e => e.TradeMsgId).HasName("PK__PlayerMa__C2FA77A23EC155AE");

            entity.ToTable("PlayerMarketTradeMsg");

            entity.Property(e => e.TradeMsgId)
                .ValueGeneratedNever()
                .HasColumnName("trade_msg_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.MessageText)
                .HasMaxLength(1)
                .HasColumnName("message_text");
            entity.Property(e => e.MsgFrom)
                .HasMaxLength(1)
                .HasColumnName("msg_from");
            entity.Property(e => e.POrderTradepageId).HasColumnName("p_order_tradepage_id");

            entity.HasOne(d => d.POrderTradepage).WithMany(p => p.PlayerMarketTradeMsgs)
                .HasForeignKey(d => d.POrderTradepageId)
                .HasConstraintName("FK__PlayerMar__p_ord__0D0FEE32");
        });

        modelBuilder.Entity<PopularityIndexDaily>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__populari__3213E83F08C19225");

            entity.ToTable("popularity_index_daily");

            entity.HasIndex(e => new { e.GameId, e.Date }, "popularity_index_daily_index_6").IsUnique();

            entity.HasIndex(e => e.Date, "popularity_index_daily_index_7");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.IndexValue)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("index_value");

            entity.HasOne(d => d.Game).WithMany(p => p.PopularityIndexDailies)
                .HasForeignKey(d => d.GameId)
                .HasConstraintName("FK__popularit__game___0539C240");
        });

        modelBuilder.Entity<Post>(entity =>
        {
            entity.HasKey(e => e.PostId).HasName("PK__posts__3ED78766F2C1BEAE");

            entity.ToTable("posts");

            entity.HasIndex(e => new { e.Type, e.CreatedAt }, "posts_index_11");

            entity.HasIndex(e => new { e.GameId, e.CreatedAt }, "posts_index_12");

            entity.HasIndex(e => new { e.Status, e.CreatedAt }, "posts_index_13");

            entity.Property(e => e.PostId).HasColumnName("post_id");
            entity.Property(e => e.BodyMd)
                .HasMaxLength(3000)
                .HasColumnName("body_md");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.Pinned).HasColumnName("pinned");
            entity.Property(e => e.PublishedAt).HasColumnName("published_at");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .HasColumnName("title");
            entity.Property(e => e.Tldr)
                .HasMaxLength(50)
                .HasColumnName("tldr");
            entity.Property(e => e.Type)
                .HasMaxLength(50)
                .HasColumnName("type");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");

            entity.HasOne(d => d.CreatedByNavigation).WithMany(p => p.Posts)
                .HasForeignKey(d => d.CreatedBy)
                .HasConstraintName("FK__posts__created_b__0169315C");

            entity.HasOne(d => d.Game).WithMany(p => p.Posts)
                .HasForeignKey(d => d.GameId)
                .HasConstraintName("FK__posts__game_id__07220AB2");
        });

        modelBuilder.Entity<PostMetricSnapshot>(entity =>
        {
            entity.HasKey(e => e.PostId).HasName("PK__post_met__3ED7876644BB3452");

            entity.ToTable("post_metric_snapshot");

            entity.Property(e => e.PostId)
                .ValueGeneratedNever()
                .HasColumnName("post_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Date).HasColumnName("date");
            entity.Property(e => e.DetailsJson).HasColumnName("details_json");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.IndexValue)
                .HasColumnType("decimal(18, 4)")
                .HasColumnName("index_value");

            entity.HasOne(d => d.Game).WithMany(p => p.PostMetricSnapshots)
                .HasForeignKey(d => d.GameId)
                .HasConstraintName("FK__post_metr__game___035179CE");

            entity.HasOne(d => d.Post).WithOne(p => p.PostMetricSnapshot)
                .HasForeignKey<PostMetricSnapshot>(d => d.PostId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__post_metr__post___025D5595");
        });

        modelBuilder.Entity<PostSource>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__post_sou__3213E83FA633BB17");

            entity.ToTable("post_sources");

            entity.HasIndex(e => e.PostId, "post_sources_index_14");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.PostId).HasColumnName("post_id");
            entity.Property(e => e.SourceName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("source_name");
            entity.Property(e => e.Url)
                .HasMaxLength(300)
                .IsUnicode(false)
                .HasColumnName("url");

            entity.HasOne(d => d.Post).WithMany(p => p.PostSources)
                .HasForeignKey(d => d.PostId)
                .HasConstraintName("FK__post_sour__post___04459E07");
        });

        modelBuilder.Entity<ProductCode>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("ProductCode");

            entity.Property(e => e.ProductCode1)
                .HasMaxLength(50)
                .HasColumnName("product_code");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
        });

        modelBuilder.Entity<ProductImage>(entity =>
        {
            entity.HasNoKey();

            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ProductimgAltText)
                .HasMaxLength(255)
                .HasColumnName("productimg_alt_text");
            entity.Property(e => e.ProductimgId)
                .ValueGeneratedOnAdd()
                .HasColumnName("productimg_id");
            entity.Property(e => e.ProductimgUpdatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("productimg_updated_at");
            entity.Property(e => e.ProductimgUrl)
                .HasMaxLength(500)
                .HasColumnName("productimg_url");
        });

        modelBuilder.Entity<ProductInfo>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("ProductInfo");

            entity.Property(e => e.CurrencyCode)
                .HasMaxLength(10)
                .HasDefaultValue("TWD")
                .HasColumnName("currency_code");
            entity.Property(e => e.Price)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("price");
            entity.Property(e => e.ProductCreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("product_created_at");
            entity.Property(e => e.ProductCreatedBy)
                .HasMaxLength(50)
                .HasColumnName("product_created_by");
            entity.Property(e => e.ProductId)
                .ValueGeneratedOnAdd()
                .HasColumnName("product_id");
            entity.Property(e => e.ProductName)
                .HasMaxLength(200)
                .HasColumnName("product_name");
            entity.Property(e => e.ProductType)
                .HasMaxLength(50)
                .HasColumnName("product_type");
            entity.Property(e => e.ProductUpdatedAt).HasColumnName("product_updated_at");
            entity.Property(e => e.ProductUpdatedBy)
                .HasMaxLength(50)
                .HasColumnName("product_updated_by");
            entity.Property(e => e.ShipmentQuantity).HasColumnName("Shipment_Quantity");
        });

        modelBuilder.Entity<ProductInfoAuditLog>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("ProductInfoAuditLog");

            entity.Property(e => e.ActionType)
                .HasMaxLength(30)
                .HasColumnName("action_type");
            entity.Property(e => e.ChangedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("changed_at");
            entity.Property(e => e.FieldName)
                .HasMaxLength(100)
                .HasColumnName("field_name");
            entity.Property(e => e.LogId)
                .ValueGeneratedOnAdd()
                .HasColumnName("log_id");
            entity.Property(e => e.ManagerId).HasColumnName("Manager_Id");
            entity.Property(e => e.NewValue).HasColumnName("new_value");
            entity.Property(e => e.OldValue).HasColumnName("old_value");
            entity.Property(e => e.ProductId).HasColumnName("product_id");

            entity.HasOne(d => d.Manager).WithMany()
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK__ProductIn__Manag__038683F8");
        });

        modelBuilder.Entity<Reaction>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__reaction__3213E83F940B04A4");

            entity.ToTable("reactions");

            entity.HasIndex(e => new { e.UserId, e.TargetType, e.TargetId, e.Kind }, "reactions_index_18").IsUnique();

            entity.HasIndex(e => new { e.TargetType, e.TargetId }, "reactions_index_19");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.Kind)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("kind");
            entity.Property(e => e.TargetId).HasColumnName("target_id");
            entity.Property(e => e.TargetType)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("target_type");
            entity.Property(e => e.UserId).HasColumnName("User_ID");

            entity.HasOne(d => d.User).WithMany(p => p.Reactions)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK__reactions__User___6ABAD62E");
        });

        modelBuilder.Entity<Relation>(entity =>
        {
            entity.HasKey(e => e.RelationId).HasName("PK__Relation__C409F3232DD45963");

            entity.ToTable("Relation");

            entity.HasIndex(e => new { e.UserId, e.FriendId }, "Relation_index_42").IsUnique();

            entity.Property(e => e.RelationId).HasColumnName("relation_id");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(sysdatetime())")
                .HasColumnName("created_at");
            entity.Property(e => e.FriendId).HasColumnName("friend_id");
            entity.Property(e => e.FriendNickname)
                .HasMaxLength(10)
                .HasColumnName("friend_nickname");
            entity.Property(e => e.StatusId).HasColumnName("status_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UserId).HasColumnName("User_ID");

            entity.HasOne(d => d.Friend).WithMany(p => p.RelationFriends)
                .HasForeignKey(d => d.FriendId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Relation__friend__22FF2F51");

            entity.HasOne(d => d.Status).WithMany(p => p.Relations)
                .HasForeignKey(d => d.StatusId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Relation__status__23F3538A");

            entity.HasOne(d => d.User).WithMany(p => p.RelationUsers)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Relation__User_I__220B0B18");
        });

        modelBuilder.Entity<RelationStatus>(entity =>
        {
            entity.HasKey(e => e.StatusId).HasName("PK__Relation__3683B531F9D20A4A");

            entity.ToTable("Relation_Status");

            entity.Property(e => e.StatusId).HasColumnName("status_id");
            entity.Property(e => e.StatusName)
                .HasMaxLength(10)
                .HasColumnName("status_name");
        });

        modelBuilder.Entity<Shipment>(entity =>
        {
            entity.HasKey(e => e.ShipmentId).HasName("PK__Shipment__41466E5960054AD2");

            entity.Property(e => e.ShipmentId).HasColumnName("shipment_id");
            entity.Property(e => e.Carrier)
                .HasMaxLength(50)
                .HasColumnName("carrier");
            entity.Property(e => e.DeliveredAt).HasColumnName("delivered_at");
            entity.Property(e => e.Note)
                .HasMaxLength(200)
                .HasColumnName("note");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.ShipmentCode)
                .HasDefaultValueSql("(NEXT VALUE FOR [dbo].[SeqShipmentCode])")
                .HasColumnName("shipment_code");
            entity.Property(e => e.ShippedAt).HasColumnName("shipped_at");
            entity.Property(e => e.Status)
                .HasMaxLength(30)
                .HasColumnName("status");
            entity.Property(e => e.TrackingNo)
                .HasMaxLength(100)
                .HasColumnName("tracking_no");
        });

        modelBuilder.Entity<StockMovement>(entity =>
        {
            entity.HasKey(e => e.MovementId).HasName("PK__StockMov__AB1D1022C599FC06");

            entity.Property(e => e.MovementId).HasColumnName("movement_id");
            entity.Property(e => e.ChangeQty).HasColumnName("change_qty");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(sysutcdatetime())")
                .HasColumnName("created_at");
            entity.Property(e => e.Note)
                .HasMaxLength(200)
                .HasColumnName("note");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.Reason)
                .HasMaxLength(30)
                .HasColumnName("reason");
        });

        modelBuilder.Entity<Style>(entity =>
        {
            entity.HasKey(e => e.StyleId).HasName("PK__Styles__D333B397F7F49430");

            entity.Property(e => e.StyleId).HasColumnName("style_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.EffectDesc)
                .HasMaxLength(255)
                .HasColumnName("effect_desc");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.StyleName)
                .HasMaxLength(10)
                .HasColumnName("style_name");

            entity.HasOne(d => d.Manager).WithMany(p => p.Styles)
                .HasForeignKey(d => d.ManagerId)
                .HasConstraintName("FK__Styles__manager___0FEC5ADD");
        });

        modelBuilder.Entity<Supplier>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Supplier");

            entity.Property(e => e.SupplierId)
                .ValueGeneratedOnAdd()
                .HasColumnName("supplier_id");
            entity.Property(e => e.SupplierName)
                .HasMaxLength(100)
                .HasColumnName("supplier_name");
        });

        modelBuilder.Entity<Thread>(entity =>
        {
            entity.HasKey(e => e.ThreadId).HasName("PK__threads__7411E2F035E8CC2A");

            entity.ToTable("threads");

            entity.HasIndex(e => new { e.ForumId, e.UpdatedAt }, "threads_index_16");

            entity.Property(e => e.ThreadId).HasColumnName("thread_id");
            entity.Property(e => e.AuthorUserId).HasColumnName("author_User_ID");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.ForumId).HasColumnName("forum_id");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
            entity.Property(e => e.Title)
                .HasMaxLength(50)
                .HasColumnName("title");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");

            entity.HasOne(d => d.AuthorUser).WithMany(p => p.Threads)
                .HasForeignKey(d => d.AuthorUserId)
                .HasConstraintName("FK__threads__author___66EA454A");

            entity.HasOne(d => d.Forum).WithMany(p => p.Threads)
                .HasForeignKey(d => d.ForumId)
                .HasConstraintName("FK__threads__forum_i__00750D23");
        });

        modelBuilder.Entity<ThreadPost>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__thread_p__3213E83F966AF56F");

            entity.ToTable("thread_posts");

            entity.HasIndex(e => new { e.ThreadId, e.CreatedAt }, "thread_posts_index_17");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AuthorUserId).HasColumnName("author_User_ID");
            entity.Property(e => e.ContentMd)
                .HasMaxLength(3000)
                .HasColumnName("content_md");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.ParentPostId).HasColumnName("parent_post_id");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
            entity.Property(e => e.ThreadId).HasColumnName("thread_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");

            entity.HasOne(d => d.AuthorUser).WithMany(p => p.ThreadPosts)
                .HasForeignKey(d => d.AuthorUserId)
                .HasConstraintName("FK__thread_po__autho__68D28DBC");

            entity.HasOne(d => d.ParentPost).WithMany(p => p.InverseParentPost)
                .HasForeignKey(d => d.ParentPostId)
                .HasConstraintName("FK__thread_po__paren__69C6B1F5");

            entity.HasOne(d => d.Thread).WithMany(p => p.ThreadPosts)
                .HasForeignKey(d => d.ThreadId)
                .HasConstraintName("FK__thread_po__threa__67DE6983");
        });

        modelBuilder.Entity<Users>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__Users__206D9190FA40893F");

            entity.HasIndex(e => e.UserName, "UQ__Users__5F1A108682A83552").IsUnique();

            entity.HasIndex(e => e.UserAccount, "UQ__Users__899F4A91E5EF8DB8").IsUnique();

            entity.Property(e => e.UserId).HasColumnName("User_ID");
            entity.Property(e => e.UserAccessFailedCount).HasColumnName("User_AccessFailedCount");
            entity.Property(e => e.UserAccount)
                .HasMaxLength(30)
                .HasColumnName("User_Account");
            entity.Property(e => e.UserEmailConfirmed).HasColumnName("User_EmailConfirmed");
            entity.Property(e => e.UserLockoutEnabled)
                .HasDefaultValue(true)
                .HasColumnName("User_LockoutEnabled");
            entity.Property(e => e.UserLockoutEnd).HasColumnName("User_LockoutEnd");
            entity.Property(e => e.UserName)
                .HasMaxLength(30)
                .HasColumnName("User_name");
            entity.Property(e => e.UserPassword)
                .HasMaxLength(30)
                .HasColumnName("User_Password");
            entity.Property(e => e.UserPhoneNumberConfirmed).HasColumnName("User_PhoneNumberConfirmed");
            entity.Property(e => e.UserTwoFactorEnabled).HasColumnName("User_TwoFactorEnabled");
        });

        modelBuilder.Entity<UserIntroduce>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__User_Int__206D91909E25154A");

            entity.ToTable("User_Introduce");

            entity.HasIndex(e => e.IdNumber, "UQ__User_Int__62DF8033EDDD19FD").IsUnique();

            entity.HasIndex(e => e.Email, "UQ__User_Int__A9D10534CAA16AC5").IsUnique();

            entity.HasIndex(e => e.Cellphone, "UQ__User_Int__CDE19CF29F238F26").IsUnique();

            entity.HasIndex(e => e.UserNickName, "UQ__User_Int__DAFD02CF797EB192").IsUnique();

            entity.Property(e => e.UserId)
                .ValueGeneratedNever()
                .HasColumnName("User_ID");
            entity.Property(e => e.Address).HasMaxLength(100);
            entity.Property(e => e.Cellphone)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.CreateAccount).HasColumnName("Create_Account");
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Gender)
                .HasMaxLength(1)
                .IsUnicode(false)
                .IsFixedLength();
            entity.Property(e => e.IdNumber)
                .HasMaxLength(30)
                .IsUnicode(false);
            entity.Property(e => e.UserIntroduce1)
                .HasMaxLength(200)
                .HasColumnName("User_Introduce");
            entity.Property(e => e.UserNickName)
                .HasMaxLength(50)
                .HasColumnName("User_NickName");
            entity.Property(e => e.UserPicture).HasColumnName("User_Picture");

            entity.HasOne(d => d.User).WithOne(p => p.UserIntroduce)
                .HasForeignKey<UserIntroduce>(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__User_Intr__User___0FB750B3");
        });

        modelBuilder.Entity<UserRight>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__User_Rig__206D91702DB5DE3E");

            entity.ToTable("User_Rights");

            entity.Property(e => e.UserId)
                .ValueGeneratedNever()
                .HasColumnName("User_Id");
            entity.Property(e => e.UserStatus).HasColumnName("User_Status");

            entity.HasOne(d => d.User).WithOne(p => p.UserRight)
                .HasForeignKey<UserRight>(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__User_Righ__User___10AB74EC");
        });

        modelBuilder.Entity<UserSalesInformation>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__User_Sal__206D9170797CCA09");

            entity.ToTable("User_Sales_Information");

            entity.Property(e => e.UserId)
                .ValueGeneratedNever()
                .HasColumnName("User_Id");
            entity.Property(e => e.UserSalesWallet).HasColumnName("UserSales_Wallet");

            entity.HasOne(d => d.User).WithOne(p => p.UserSalesInformation)
                .HasForeignKey<UserSalesInformation>(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__User_Sale__User___1293BD5E");
        });

        modelBuilder.Entity<UserSignInStat>(entity =>
        {
            entity.HasNoKey();

            entity.HasIndex(e => new { e.UserId, e.SignTime }, "UserSignInStats_index_22");

            entity.Property(e => e.CouponGained)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LogId).HasColumnName("LogID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__UserSignI__UserI__6D9742D9");
        });

        modelBuilder.Entity<UserToken>(entity =>
        {
            entity.HasKey(e => e.TokenId).HasName("PK__UserToke__AA16D540EFFF863A");

            entity.Property(e => e.TokenId).HasColumnName("Token_ID");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.Provider).HasMaxLength(50);
            entity.Property(e => e.UserId).HasColumnName("User_ID");
            entity.Property(e => e.Value).HasMaxLength(255);

            entity.HasOne(d => d.User).WithMany(p => p.UserTokens)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__UserToken__User___0EC32C7A");
        });

        modelBuilder.Entity<UserWallet>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("User_Wallet");

            entity.Property(e => e.UserId).HasColumnName("User_Id");
            entity.Property(e => e.UserPoint).HasColumnName("User_Point");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__User_Wall__User___6CA31EA0");
        });

        modelBuilder.Entity<WalletHistory>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("WalletHistory");

            entity.HasIndex(e => new { e.UserId, e.ChangeTime }, "WalletHistory_index_30");

            entity.HasIndex(e => new { e.ChangeType, e.ChangeTime }, "WalletHistory_index_31");

            entity.Property(e => e.ChangeType).HasMaxLength(10);
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ItemCode)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.LogId).HasColumnName("LogID");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__WalletHis__UserI__62E4AA3C");
        });
        // 配置 DM_Conversations 模型
        modelBuilder.Entity<DM_Conversations>(entity =>
        {
            entity.HasKey(e => e.ConversationId).HasName("PK_DM_Conversations");
            entity.ToTable("DM_Conversations");
            entity.Property(e => e.ConversationId).HasColumnName("conversation_id");
            entity.Property(e => e.IsManagerDm).HasColumnName("is_manager_dm");
            entity.Property(e => e.Party1Id).HasColumnName("party1_id");
            entity.Property(e => e.Party2Id).HasColumnName("party2_id");
            entity.Property(e => e.LastMessageAt).HasColumnName("last_message_at");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.IsPrivate).HasColumnName("is_private");
            entity.Property(e => e.ConversationName).HasColumnName("conversation_name");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.SenderIsParty1).HasColumnName("sender_is_party1");
            entity.Property(e => e.LastMessageId).HasColumnName("last_message_id");
            entity.Property(e => e.MessageCount).HasColumnName("message_count");
            entity.Property(e => e.IsArchived).HasColumnName("is_archived");
            entity.Property(e => e.ArchivedAt).HasColumnName("archived_at");
            entity.Property(e => e.ArchiveReason).HasColumnName("archive_reason");
        });

        // 配置 DM_Messages 模型
        modelBuilder.Entity<DM_Messages>(entity =>
        {
            entity.HasKey(e => e.MessageId).HasName("PK_DM_Messages");
            entity.ToTable("DM_Messages");
            entity.Property(e => e.MessageId).HasColumnName("message_id");
            entity.Property(e => e.ConversationId).HasColumnName("conversation_id");
            entity.Property(e => e.SenderUserId).HasColumnName("sender_user_id");
            entity.Property(e => e.SenderManagerId).HasColumnName("sender_manager_id");
            entity.Property(e => e.MessageText).HasColumnName("message_text");
            entity.Property(e => e.SentAt).HasColumnName("sent_at");
            entity.Property(e => e.IsRead).HasColumnName("is_read");
            entity.Property(e => e.ReadAt).HasColumnName("read_at");
            entity.Property(e => e.ReadByUserId).HasColumnName("read_by_user_id");
            entity.Property(e => e.ReadByManagerId).HasColumnName("read_by_manager_id");
            entity.Property(e => e.IsEdited).HasColumnName("is_edited");
            entity.Property(e => e.EditedAt).HasColumnName("edited_at");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedByUserId).HasColumnName("deleted_by_user_id");
            entity.Property(e => e.DeletedByManagerId).HasColumnName("deleted_by_manager_id");
            entity.Property(e => e.MessageType).HasColumnName("message_type");
            entity.Property(e => e.AttachmentUrl).HasColumnName("attachment_url");
            entity.Property(e => e.AttachmentType).HasColumnName("attachment_type");
            entity.Property(e => e.ReplyToMessageId).HasColumnName("reply_to_message_id");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
        });

        // 配置 GameProductDetails 模型
        modelBuilder.Entity<GameProductDetails>(entity =>
        {
            entity.ToTable("GameProductDetails");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ProductName).HasColumnName("product_name");
            entity.Property(e => e.GameId).HasColumnName("game_id");
            entity.Property(e => e.ProductType).HasColumnName("product_type");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.CurrencyCode).HasColumnName("currency_code");
            entity.Property(e => e.ImageUrl).HasColumnName("image_url");
            entity.Property(e => e.VideoUrl).HasColumnName("video_url");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.PublishedAt).HasColumnName("published_at");
            entity.Property(e => e.UnpublishedAt).HasColumnName("unpublished_at");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Specifications).HasColumnName("specifications");
            entity.Property(e => e.Features).HasColumnName("features");
            entity.Property(e => e.Requirements).HasColumnName("requirements");
            entity.Property(e => e.Rating).HasColumnName("rating");
            entity.Property(e => e.RatingCount).HasColumnName("rating_count");
            entity.Property(e => e.ViewCount).HasColumnName("view_count");
            entity.Property(e => e.PurchaseCount).HasColumnName("purchase_count");
            entity.Property(e => e.Weight).HasColumnName("weight");
            entity.Property(e => e.Dimensions).HasColumnName("dimensions");
            entity.Property(e => e.Material).HasColumnName("material");
            entity.Property(e => e.Color).HasColumnName("color");
            entity.Property(e => e.Brand).HasColumnName("brand");
            entity.Property(e => e.Model).HasColumnName("model");
            entity.Property(e => e.Barcode).HasColumnName("barcode");
            entity.Property(e => e.Sku).HasColumnName("sku");
            entity.Property(e => e.Stock).HasColumnName("stock");
            entity.Property(e => e.MinStock).HasColumnName("min_stock");
            entity.Property(e => e.Notes).HasColumnName("notes");
        });

        // 配置 Group_Read_States 模型
        modelBuilder.Entity<Group_Read_States>(entity =>
        {
            entity.HasKey(e => e.StateId).HasName("PK_Group_Read_States");
            entity.ToTable("Group_Read_States");
            entity.Property(e => e.StateId).HasColumnName("state_id");
            entity.Property(e => e.GroupId).HasColumnName("group_id");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.LastReadMessageId).HasColumnName("last_read_message_id");
            entity.Property(e => e.LastReadAt).HasColumnName("last_read_at");
            entity.Property(e => e.UnreadCount).HasColumnName("unread_count");
            entity.Property(e => e.IsMuted).HasColumnName("is_muted");
            entity.Property(e => e.MutedAt).HasColumnName("muted_at");
            entity.Property(e => e.MuteExpiresAt).HasColumnName("mute_expires_at");
            entity.Property(e => e.IsBlocked).HasColumnName("is_blocked");
            entity.Property(e => e.BlockedAt).HasColumnName("blocked_at");
            entity.Property(e => e.BlockReason).HasColumnName("block_reason");
            entity.Property(e => e.HasLeft).HasColumnName("has_left");
            entity.Property(e => e.LeftAt).HasColumnName("left_at");
            entity.Property(e => e.LeaveReason).HasColumnName("leave_reason");
            entity.Property(e => e.HasJoined).HasColumnName("has_joined");
            entity.Property(e => e.JoinedAt).HasColumnName("joined_at");
            entity.Property(e => e.Role).HasColumnName("role");
            entity.Property(e => e.Permissions).HasColumnName("permissions");
            entity.Property(e => e.LastActivityAt).HasColumnName("last_activity_at");
            entity.Property(e => e.ReceiveNotifications).HasColumnName("receive_notifications");
            entity.Property(e => e.NotificationSettings).HasColumnName("notification_settings");
            entity.Property(e => e.GroupNickname).HasColumnName("group_nickname");
            entity.Property(e => e.PersonalNote).HasColumnName("personal_note");
            entity.Property(e => e.IsPinned).HasColumnName("is_pinned");
            entity.Property(e => e.PinnedAt).HasColumnName("pinned_at");
            entity.Property(e => e.PinOrder).HasColumnName("pin_order");
        });

        // 配置 Groups 模型
        modelBuilder.Entity<Groups>(entity =>
        {
            entity.HasKey(e => e.GroupId).HasName("PK_Groups");
            entity.ToTable("Groups");
            entity.Property(e => e.GroupId).HasColumnName("group_id");
            entity.Property(e => e.OwnerUserId).HasColumnName("owner_user_id");
            entity.Property(e => e.GroupName).HasColumnName("group_name");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.AvatarUrl).HasColumnName("avatar_url");
            entity.Property(e => e.CoverUrl).HasColumnName("cover_url");
            entity.Property(e => e.GroupType).HasColumnName("group_type");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsPublic).HasColumnName("is_public");
            entity.Property(e => e.RequiresApproval).HasColumnName("requires_approval");
            entity.Property(e => e.MaxMembers).HasColumnName("max_members");
            entity.Property(e => e.CurrentMembers).HasColumnName("current_members");
            entity.Property(e => e.Rules).HasColumnName("rules");
            entity.Property(e => e.Settings).HasColumnName("settings");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.LastActivityAt).HasColumnName("last_activity_at");
            entity.Property(e => e.IsArchived).HasColumnName("is_archived");
            entity.Property(e => e.ArchivedAt).HasColumnName("archived_at");
            entity.Property(e => e.ArchiveReason).HasColumnName("archive_reason");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.Level).HasColumnName("level");
            entity.Property(e => e.Experience).HasColumnName("experience");
            entity.Property(e => e.Points).HasColumnName("points");
            entity.Property(e => e.Ranking).HasColumnName("ranking");
            entity.Property(e => e.Rating).HasColumnName("rating");
            entity.Property(e => e.RatingCount).HasColumnName("rating_count");
            entity.Property(e => e.ViewCount).HasColumnName("view_count");
            entity.Property(e => e.JoinCount).HasColumnName("join_count");
            entity.Property(e => e.LeaveCount).HasColumnName("leave_count");
            entity.Property(e => e.Location).HasColumnName("location");
            entity.Property(e => e.Website).HasColumnName("website");
            entity.Property(e => e.Contact).HasColumnName("contact");
            entity.Property(e => e.Language).HasColumnName("language");
            entity.Property(e => e.Timezone).HasColumnName("timezone");
            entity.Property(e => e.Notes).HasColumnName("notes");
        });

        // 配置 ManagerData 模型
        modelBuilder.Entity<ManagerData>(entity =>
        {
            entity.HasKey(e => e.ManagerId).HasName("PK_ManagerData");
            entity.ToTable("ManagerData");
            entity.Property(e => e.ManagerId).HasColumnName("Manager_Id");
            entity.Property(e => e.ManagerName).HasColumnName("Manager_Name");
            entity.Property(e => e.ManagerAccount).HasColumnName("Manager_Account");
            entity.Property(e => e.ManagerPassword).HasColumnName("Manager_Password");
            entity.Property(e => e.ManagerEmail).HasColumnName("Manager_Email");
            entity.Property(e => e.ManagerEmailConfirmed).HasColumnName("Manager_EmailConfirmed");
            entity.Property(e => e.ManagerPhone).HasColumnName("Manager_Phone");
            entity.Property(e => e.ManagerPhoneConfirmed).HasColumnName("Manager_PhoneConfirmed");
            entity.Property(e => e.ManagerStatus).HasColumnName("Manager_Status");
            entity.Property(e => e.ManagerRole).HasColumnName("Manager_Role");
            entity.Property(e => e.ManagerPermissions).HasColumnName("Manager_Permissions");
            entity.Property(e => e.Department).HasColumnName("Department");
            entity.Property(e => e.Position).HasColumnName("Position");
            entity.Property(e => e.Level).HasColumnName("Level");
            entity.Property(e => e.AvatarUrl).HasColumnName("Avatar_Url");
            entity.Property(e => e.Profile).HasColumnName("Profile");
            entity.Property(e => e.Notes).HasColumnName("Notes");
            entity.Property(e => e.AdministratorRegistrationDate).HasColumnName("Administrator_registration_date");
            entity.Property(e => e.LastLoginAt).HasColumnName("Last_Login_At");
            entity.Property(e => e.LastLoginIp).HasColumnName("Last_Login_Ip");
            entity.Property(e => e.ManagerAccessFailedCount).HasColumnName("Manager_AccessFailedCount");
            entity.Property(e => e.ManagerLockoutEnabled).HasColumnName("Manager_LockoutEnabled");
            entity.Property(e => e.ManagerLockoutEnd).HasColumnName("Manager_LockoutEnd");
            entity.Property(e => e.ManagerTwoFactorEnabled).HasColumnName("Manager_TwoFactorEnabled");
            entity.Property(e => e.CreatedAt).HasColumnName("Created_At");
            entity.Property(e => e.UpdatedAt).HasColumnName("Updated_At");
            entity.Property(e => e.CreatedBy).HasColumnName("Created_By");
            entity.Property(e => e.UpdatedBy).HasColumnName("Updated_By");
            entity.Property(e => e.IsDeleted).HasColumnName("Is_Deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("Deleted_At");
            entity.Property(e => e.DeletedBy).HasColumnName("Deleted_By");
            entity.Property(e => e.Settings).HasColumnName("Settings");
            entity.Property(e => e.Preferences).HasColumnName("Preferences");
            entity.Property(e => e.WorkSchedule).HasColumnName("Work_Schedule");
            entity.Property(e => e.ContactInfo).HasColumnName("Contact_Info");
            entity.Property(e => e.EmergencyContact).HasColumnName("Emergency_Contact");
            entity.Property(e => e.Address).HasColumnName("Address");
            entity.Property(e => e.BirthDate).HasColumnName("Birth_Date");
            entity.Property(e => e.Gender).HasColumnName("Gender");
            entity.Property(e => e.IdNumber).HasColumnName("Id_Number");
            entity.Property(e => e.BankAccountNumber).HasColumnName("Bank_Account_Number");
            entity.Property(e => e.BankCode).HasColumnName("Bank_Code");
        });

        // 配置 Mutes 模型
        modelBuilder.Entity<Mutes>(entity =>
        {
            entity.HasKey(e => e.MuteId).HasName("PK_Mutes");
            entity.ToTable("Mutes");
            entity.Property(e => e.MuteId).HasColumnName("mute_id");
            entity.Property(e => e.Word).HasColumnName("word");
            entity.Property(e => e.MuteType).HasColumnName("mute_type");
            entity.Property(e => e.Reason).HasColumnName("reason");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.CreatedByManagerId).HasColumnName("created_by_manager_id");
            entity.Property(e => e.CreatedByUserId).HasColumnName("created_by_user_id");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedByManagerId).HasColumnName("updated_by_manager_id");
            entity.Property(e => e.UpdatedByUserId).HasColumnName("updated_by_user_id");
            entity.Property(e => e.MuteStartAt).HasColumnName("mute_start_at");
            entity.Property(e => e.MuteEndAt).HasColumnName("mute_end_at");
            entity.Property(e => e.IsPermanent).HasColumnName("is_permanent");
            entity.Property(e => e.Scope).HasColumnName("scope");
            entity.Property(e => e.TargetType).HasColumnName("target_type");
            entity.Property(e => e.TargetId).HasColumnName("target_id");
            entity.Property(e => e.Severity).HasColumnName("severity");
            entity.Property(e => e.MuteCount).HasColumnName("mute_count");
            entity.Property(e => e.LastTriggeredAt).HasColumnName("last_triggered_at");
            entity.Property(e => e.TriggerCount).HasColumnName("trigger_count");
            entity.Property(e => e.IsAutoMute).HasColumnName("is_auto_mute");
            entity.Property(e => e.AutoMuteCondition).HasColumnName("auto_mute_condition");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.Priority).HasColumnName("priority");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
        });

        // 配置 Notifications 模型
        modelBuilder.Entity<Notifications>(entity =>
        {
            entity.HasKey(e => e.NotificationId).HasName("PK_Notifications");
            entity.ToTable("Notifications");
            entity.Property(e => e.NotificationId).HasColumnName("notification_id");
            entity.Property(e => e.SourceId).HasColumnName("source_id");
            entity.Property(e => e.Title).HasColumnName("title");
            entity.Property(e => e.Content).HasColumnName("content");
            entity.Property(e => e.NotificationType).HasColumnName("notification_type");
            entity.Property(e => e.Priority).HasColumnName("priority");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsRead).HasColumnName("is_read");
            entity.Property(e => e.ReadAt).HasColumnName("read_at");
            entity.Property(e => e.ReadBy).HasColumnName("read_by");
            entity.Property(e => e.SentAt).HasColumnName("sent_at");
            entity.Property(e => e.SenderUserId).HasColumnName("sender_user_id");
            entity.Property(e => e.SenderManagerId).HasColumnName("sender_manager_id");
            entity.Property(e => e.TargetType).HasColumnName("target_type");
            entity.Property(e => e.TargetId).HasColumnName("target_id");
            entity.Property(e => e.Action).HasColumnName("action");
            entity.Property(e => e.ActionUrl).HasColumnName("action_url");
            entity.Property(e => e.Data).HasColumnName("data");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.Channel).HasColumnName("channel");
            entity.Property(e => e.Platform).HasColumnName("platform");
            entity.Property(e => e.Language).HasColumnName("language");
            entity.Property(e => e.Timezone).HasColumnName("timezone");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.ExpiresAt).HasColumnName("expires_at");
            entity.Property(e => e.IsExpired).HasColumnName("is_expired");
            entity.Property(e => e.IsSent).HasColumnName("is_sent");
            entity.Property(e => e.SendFailureCount).HasColumnName("send_failure_count");
            entity.Property(e => e.LastSendAttemptAt).HasColumnName("last_send_attempt_at");
            entity.Property(e => e.SendErrorMessage).HasColumnName("send_error_message");
            entity.Property(e => e.IsCancelled).HasColumnName("is_cancelled");
            entity.Property(e => e.CancelledAt).HasColumnName("cancelled_at");
            entity.Property(e => e.CancelledBy).HasColumnName("cancelled_by");
            entity.Property(e => e.CancelReason).HasColumnName("cancel_reason");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 OrderAddresses 模型
        modelBuilder.Entity<OrderAddresses>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK_OrderAddresses");
            entity.ToTable("OrderAddresses");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.Recipient).HasColumnName("recipient");
            entity.Property(e => e.Phone).HasColumnName("phone");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.AddressType).HasColumnName("address_type");
            entity.Property(e => e.Country).HasColumnName("country");
            entity.Property(e => e.City).HasColumnName("city");
            entity.Property(e => e.District).HasColumnName("district");
            entity.Property(e => e.ZipCode).HasColumnName("zipcode");
            entity.Property(e => e.Address1).HasColumnName("address1");
            entity.Property(e => e.Address2).HasColumnName("address2");
            entity.Property(e => e.FullAddress).HasColumnName("full_address");
            entity.Property(e => e.Latitude).HasColumnName("latitude");
            entity.Property(e => e.Longitude).HasColumnName("longitude");
            entity.Property(e => e.ValidationStatus).HasColumnName("validation_status");
            entity.Property(e => e.ValidatedAt).HasColumnName("validated_at");
            entity.Property(e => e.ValidatedBy).HasColumnName("validated_by");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.IsDefault).HasColumnName("is_default");
            entity.Property(e => e.IsBillingAddress).HasColumnName("is_billing_address");
            entity.Property(e => e.IsShippingAddress).HasColumnName("is_shipping_address");
            entity.Property(e => e.DeliveryTimePreference).HasColumnName("delivery_time_preference");
            entity.Property(e => e.DeliveryNotes).HasColumnName("delivery_notes");
            entity.Property(e => e.SpecialInstructions).HasColumnName("special_instructions");
            entity.Property(e => e.DeliveryFee).HasColumnName("delivery_fee");
            entity.Property(e => e.DeliveryMethod).HasColumnName("delivery_method");
            entity.Property(e => e.DeliveryCompany).HasColumnName("delivery_company");
            entity.Property(e => e.TrackingNumber).HasColumnName("tracking_number");
            entity.Property(e => e.DeliveryStatus).HasColumnName("delivery_status");
            entity.Property(e => e.DeliveredAt).HasColumnName("delivered_at");
            entity.Property(e => e.DeliveredTo).HasColumnName("delivered_to");
            entity.Property(e => e.SignedAt).HasColumnName("signed_at");
            entity.Property(e => e.SignatureNotes).HasColumnName("signature_notes");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 OrderItems 模型
        modelBuilder.Entity<OrderItems>(entity =>
        {
            entity.HasKey(e => e.OrderItemId).HasName("PK_OrderItems");
            entity.ToTable("OrderItems");
            entity.Property(e => e.OrderItemId).HasColumnName("order_item_id");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ProductName).HasColumnName("product_name");
            entity.Property(e => e.ProductType).HasColumnName("product_type");
            entity.Property(e => e.ProductSku).HasColumnName("product_sku");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.UnitPrice).HasColumnName("unit_price");
            entity.Property(e => e.TotalPrice).HasColumnName("total_price");
            entity.Property(e => e.DiscountAmount).HasColumnName("discount_amount");
            entity.Property(e => e.TaxAmount).HasColumnName("tax_amount");
            entity.Property(e => e.ShippingCost).HasColumnName("shipping_cost");
            entity.Property(e => e.CurrencyCode).HasColumnName("currency_code");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.Specifications).HasColumnName("specifications");
            entity.Property(e => e.Variants).HasColumnName("variants");
            entity.Property(e => e.Customizations).HasColumnName("customizations");
            entity.Property(e => e.GiftMessage).HasColumnName("gift_message");
            entity.Property(e => e.IsGift).HasColumnName("is_gift");
            entity.Property(e => e.GiftWrapType).HasColumnName("gift_wrap_type");
            entity.Property(e => e.GiftWrapCost).HasColumnName("gift_wrap_cost");
            entity.Property(e => e.WarrantyInfo).HasColumnName("warranty_info");
            entity.Property(e => e.ReturnPolicy).HasColumnName("return_policy");
            entity.Property(e => e.IsReturnable).HasColumnName("is_returnable");
            entity.Property(e => e.ReturnDeadline).HasColumnName("return_deadline");
            entity.Property(e => e.SupplierInfo).HasColumnName("supplier_info");
            entity.Property(e => e.InventoryLocation).HasColumnName("inventory_location");
            entity.Property(e => e.TrackingInfo).HasColumnName("tracking_info");
            entity.Property(e => e.DeliveryInstructions).HasColumnName("delivery_instructions");
            entity.Property(e => e.SpecialRequirements).HasColumnName("special_requirements");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.Weight).HasColumnName("weight");
            entity.Property(e => e.Dimensions).HasColumnName("dimensions");
            entity.Property(e => e.Material).HasColumnName("material");
            entity.Property(e => e.Color).HasColumnName("color");
            entity.Property(e => e.Size).HasColumnName("size");
            entity.Property(e => e.Brand).HasColumnName("brand");
            entity.Property(e => e.Model).HasColumnName("model");
            entity.Property(e => e.Barcode).HasColumnName("barcode");
            entity.Property(e => e.ImageUrl).HasColumnName("image_url");
            entity.Property(e => e.VideoUrl).HasColumnName("video_url");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.Features).HasColumnName("features");
            entity.Property(e => e.Requirements).HasColumnName("requirements");
            entity.Property(e => e.Rating).HasColumnName("rating");
            entity.Property(e => e.RatingCount).HasColumnName("rating_count");
            entity.Property(e => e.ViewCount).HasColumnName("view_count");
            entity.Property(e => e.PurchaseCount).HasColumnName("purchase_count");
            entity.Property(e => e.Reviews).HasColumnName("reviews");
            entity.Property(e => e.Qa).HasColumnName("qa");
            entity.Property(e => e.Faq).HasColumnName("faq");
            entity.Property(e => e.Manual).HasColumnName("manual");
            entity.Property(e => e.SupportInfo).HasColumnName("support_info");
            entity.Property(e => e.RelatedProducts).HasColumnName("related_products");
            entity.Property(e => e.CrossSells).HasColumnName("cross_sells");
            entity.Property(e => e.UpSells).HasColumnName("up_sells");
            entity.Property(e => e.Bundles).HasColumnName("bundles");
            entity.Property(e => e.Promotions).HasColumnName("promotions");
            entity.Property(e => e.Coupons).HasColumnName("coupons");
            entity.Property(e => e.LoyaltyPoints).HasColumnName("loyalty_points");
            entity.Property(e => e.Rewards).HasColumnName("rewards");
            entity.Property(e => e.Settings).HasColumnName("settings");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
        });

        // 配置 OtherProductDetails 模型
        modelBuilder.Entity<OtherProductDetails>(entity =>
        {
            entity.HasKey(e => e.ProductId).HasName("PK_OtherProductDetails");
            entity.ToTable("OtherProductDetails");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ProductName).HasColumnName("product_name");
            entity.Property(e => e.ProductType).HasColumnName("product_type");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.CurrencyCode).HasColumnName("currency_code");
            entity.Property(e => e.ImageUrl).HasColumnName("image_url");
            entity.Property(e => e.VideoUrl).HasColumnName("video_url");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.PublishedAt).HasColumnName("published_at");
            entity.Property(e => e.UnpublishedAt).HasColumnName("unpublished_at");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.Specifications).HasColumnName("specifications");
            entity.Property(e => e.Features).HasColumnName("features");
            entity.Property(e => e.Requirements).HasColumnName("requirements");
            entity.Property(e => e.Rating).HasColumnName("rating");
            entity.Property(e => e.RatingCount).HasColumnName("rating_count");
            entity.Property(e => e.ViewCount).HasColumnName("view_count");
            entity.Property(e => e.PurchaseCount).HasColumnName("purchase_count");
            entity.Property(e => e.Weight).HasColumnName("weight");
            entity.Property(e => e.Dimensions).HasColumnName("dimensions");
            entity.Property(e => e.Material).HasColumnName("material");
            entity.Property(e => e.Color).HasColumnName("color");
            entity.Property(e => e.Brand).HasColumnName("brand");
            entity.Property(e => e.Model).HasColumnName("model");
            entity.Property(e => e.Barcode).HasColumnName("barcode");
            entity.Property(e => e.Sku).HasColumnName("sku");
            entity.Property(e => e.Stock).HasColumnName("stock");
            entity.Property(e => e.MinStock).HasColumnName("min_stock");
            entity.Property(e => e.Notes).HasColumnName("notes");
        });

        // 配置 PaymentTransactions 模型
        modelBuilder.Entity<PaymentTransactions>(entity =>
        {
            entity.HasKey(e => e.TransactionId).HasName("PK_PaymentTransactions");
            entity.ToTable("PaymentTransactions");
            entity.Property(e => e.TransactionId).HasColumnName("transaction_id");
            entity.Property(e => e.TransactionCode).HasColumnName("transaction_code");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Amount).HasColumnName("amount");
            entity.Property(e => e.CurrencyCode).HasColumnName("currency_code");
            entity.Property(e => e.PaymentMethod).HasColumnName("payment_method");
            entity.Property(e => e.PaymentProvider).HasColumnName("payment_provider");
            entity.Property(e => e.PaymentStatus).HasColumnName("payment_status");
            entity.Property(e => e.PaymentReference).HasColumnName("payment_reference");
            entity.Property(e => e.PaymentGatewayResponse).HasColumnName("payment_gateway_response");
            entity.Property(e => e.PaymentGatewayTransactionId).HasColumnName("payment_gateway_transaction_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.ProcessedAt).HasColumnName("processed_at");
            entity.Property(e => e.CompletedAt).HasColumnName("completed_at");
            entity.Property(e => e.FailedAt).HasColumnName("failed_at");
            entity.Property(e => e.CancelledAt).HasColumnName("cancelled_at");
            entity.Property(e => e.RefundedAt).HasColumnName("refunded_at");
            entity.Property(e => e.FailureReason).HasColumnName("failure_reason");
            entity.Property(e => e.CancellationReason).HasColumnName("cancellation_reason");
            entity.Property(e => e.RefundReason).HasColumnName("refund_reason");
            entity.Property(e => e.RefundAmount).HasColumnName("refund_amount");
            entity.Property(e => e.RefundReference).HasColumnName("refund_reference");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 PlayerMarketProductImgs 模型
        modelBuilder.Entity<PlayerMarketProductImgs>(entity =>
        {
            entity.HasKey(e => e.ImageId).HasName("PK_PlayerMarketProductImgs");
            entity.ToTable("PlayerMarketProductImgs");
            entity.Property(e => e.ImageId).HasColumnName("image_id");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ImageUrl).HasColumnName("image_url");
            entity.Property(e => e.ImageType).HasColumnName("image_type");
            entity.Property(e => e.ImageFormat).HasColumnName("image_format");
            entity.Property(e => e.ImageSize).HasColumnName("image_size");
            entity.Property(e => e.Width).HasColumnName("width");
            entity.Property(e => e.Height).HasColumnName("height");
            entity.Property(e => e.AltText).HasColumnName("alt_text");
            entity.Property(e => e.Caption).HasColumnName("caption");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.IsPrimary).HasColumnName("is_primary");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 ProductImages 模型
        modelBuilder.Entity<ProductImages>(entity =>
        {
            entity.HasKey(e => e.ImageId).HasName("PK_ProductImages");
            entity.ToTable("ProductImages");
            entity.Property(e => e.ImageId).HasColumnName("image_id");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.ImageUrl).HasColumnName("image_url");
            entity.Property(e => e.ImageType).HasColumnName("image_type");
            entity.Property(e => e.ImageFormat).HasColumnName("image_format");
            entity.Property(e => e.ImageSize).HasColumnName("image_size");
            entity.Property(e => e.Width).HasColumnName("width");
            entity.Property(e => e.Height).HasColumnName("height");
            entity.Property(e => e.AltText).HasColumnName("alt_text");
            entity.Property(e => e.Caption).HasColumnName("caption");
            entity.Property(e => e.SortOrder).HasColumnName("sort_order");
            entity.Property(e => e.IsPrimary).HasColumnName("is_primary");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 Shipments 模型
        modelBuilder.Entity<Shipments>(entity =>
        {
            entity.HasKey(e => e.ShipmentId).HasName("PK_Shipments");
            entity.ToTable("Shipments");
            entity.Property(e => e.ShipmentId).HasColumnName("shipment_id");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.TrackingNumber).HasColumnName("tracking_number");
            entity.Property(e => e.Carrier).HasColumnName("carrier");
            entity.Property(e => e.ServiceType).HasColumnName("service_type");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.ShippedAt).HasColumnName("shipped_at");
            entity.Property(e => e.DeliveredAt).HasColumnName("delivered_at");
            entity.Property(e => e.ExpectedDeliveryAt).HasColumnName("expected_delivery_at");
            entity.Property(e => e.DeliveryAddress).HasColumnName("delivery_address");
            entity.Property(e => e.RecipientName).HasColumnName("recipient_name");
            entity.Property(e => e.RecipientPhone).HasColumnName("recipient_phone");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.ShippingCost).HasColumnName("shipping_cost");
            entity.Property(e => e.CurrencyCode).HasColumnName("currency_code");
            entity.Property(e => e.PackageType).HasColumnName("package_type");
            entity.Property(e => e.Weight).HasColumnName("weight");
            entity.Property(e => e.Dimensions).HasColumnName("dimensions");
            entity.Property(e => e.InsuranceValue).HasColumnName("insurance_value");
            entity.Property(e => e.RequiresSignature).HasColumnName("requires_signature");
            entity.Property(e => e.IsFragile).HasColumnName("is_fragile");
            entity.Property(e => e.IsHazardous).HasColumnName("is_hazardous");
            entity.Property(e => e.SpecialInstructions).HasColumnName("special_instructions");
            entity.Property(e => e.DeliveryInstructions).HasColumnName("delivery_instructions");
            entity.Property(e => e.DeliveryTimePreference).HasColumnName("delivery_time_preference");
            entity.Property(e => e.DeliveryMethod).HasColumnName("delivery_method");
            entity.Property(e => e.DeliveryCompany).HasColumnName("delivery_company");
            entity.Property(e => e.DeliveryStatus).HasColumnName("delivery_status");
            entity.Property(e => e.DeliveredTo).HasColumnName("delivered_to");
            entity.Property(e => e.SignedAt).HasColumnName("signed_at");
            entity.Property(e => e.SignatureNotes).HasColumnName("signature_notes");
            entity.Property(e => e.DeliveryProof).HasColumnName("delivery_proof");
            entity.Property(e => e.DeliveryPhoto).HasColumnName("delivery_photo");
            entity.Property(e => e.DeliveryVideo).HasColumnName("delivery_video");
            entity.Property(e => e.DeliveryAudio).HasColumnName("delivery_audio");
            entity.Property(e => e.DeliveryLocation).HasColumnName("delivery_location");
            entity.Property(e => e.DeliveryLatitude).HasColumnName("delivery_latitude");
            entity.Property(e => e.DeliveryLongitude).HasColumnName("delivery_longitude");
            entity.Property(e => e.DeliveryAccuracy).HasColumnName("delivery_accuracy");
            entity.Property(e => e.DeliveryAltitude).HasColumnName("delivery_altitude");
            entity.Property(e => e.DeliverySpeed).HasColumnName("delivery_speed");
            entity.Property(e => e.DeliveryDirection).HasColumnName("delivery_direction");
            entity.Property(e => e.DeliveryDistance).HasColumnName("delivery_distance");
            entity.Property(e => e.DeliveryDuration).HasColumnName("delivery_duration");
            entity.Property(e => e.DeliveryRoute).HasColumnName("delivery_route");
            entity.Property(e => e.DeliveryStops).HasColumnName("delivery_stops");
            entity.Property(e => e.DeliveryDelays).HasColumnName("delivery_delays");
            entity.Property(e => e.DeliveryIssues).HasColumnName("delivery_issues");
            entity.Property(e => e.DeliveryResolutions).HasColumnName("delivery_resolutions");
            entity.Property(e => e.DeliveryFeedback).HasColumnName("delivery_feedback");
            entity.Property(e => e.DeliveryRating).HasColumnName("delivery_rating");
            entity.Property(e => e.DeliveryComments).HasColumnName("delivery_comments");
            entity.Property(e => e.DeliveryTags).HasColumnName("delivery_tags");
            entity.Property(e => e.DeliveryCategory).HasColumnName("delivery_category");
            entity.Property(e => e.DeliverySubCategory).HasColumnName("delivery_sub_category");
            entity.Property(e => e.DeliveryMetadata).HasColumnName("delivery_metadata");
            entity.Property(e => e.DeliverySettings).HasColumnName("delivery_settings");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
        });

        // 配置 StockMovements 模型
        modelBuilder.Entity<StockMovements>(entity =>
        {
            entity.HasKey(e => e.MovementId).HasName("PK_StockMovements");
            entity.ToTable("StockMovements");
            entity.Property(e => e.MovementId).HasColumnName("movement_id");
            entity.Property(e => e.ProductId).HasColumnName("product_id");
            entity.Property(e => e.MovementType).HasColumnName("movement_type");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.PreviousStock).HasColumnName("previous_stock");
            entity.Property(e => e.NewStock).HasColumnName("new_stock");
            entity.Property(e => e.Reason).HasColumnName("reason");
            entity.Property(e => e.Reference).HasColumnName("reference");
            entity.Property(e => e.OrderId).HasColumnName("order_id");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 Support_Ticket_Assignments 模型
        modelBuilder.Entity<Support_Ticket_Assignments>(entity =>
        {
            entity.HasKey(e => e.AssignmentId).HasName("PK_Support_Ticket_Assignments");
            entity.ToTable("Support_Ticket_Assignments");
            entity.Property(e => e.AssignmentId).HasColumnName("assignment_id");
            entity.Property(e => e.TicketId).HasColumnName("ticket_id");
            entity.Property(e => e.ManagerId).HasColumnName("manager_id");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.AssignedAt).HasColumnName("assigned_at");
            entity.Property(e => e.UnassignedAt).HasColumnName("unassigned_at");
            entity.Property(e => e.AssignedBy).HasColumnName("assigned_by");
            entity.Property(e => e.UnassignedBy).HasColumnName("unassigned_by");
            entity.Property(e => e.AssignmentReason).HasColumnName("assignment_reason");
            entity.Property(e => e.UnassignmentReason).HasColumnName("unassignment_reason");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 Support_Ticket_Messages 模型
        modelBuilder.Entity<Support_Ticket_Messages>(entity =>
        {
            entity.HasKey(e => e.MessageId).HasName("PK_Support_Ticket_Messages");
            entity.ToTable("Support_Ticket_Messages");
            entity.Property(e => e.MessageId).HasColumnName("message_id");
            entity.Property(e => e.TicketId).HasColumnName("ticket_id");
            entity.Property(e => e.SenderUserId).HasColumnName("sender_user_id");
            entity.Property(e => e.SenderManagerId).HasColumnName("sender_manager_id");
            entity.Property(e => e.MessageText).HasColumnName("message_text");
            entity.Property(e => e.SentAt).HasColumnName("sent_at");
            entity.Property(e => e.IsRead).HasColumnName("is_read");
            entity.Property(e => e.ReadAt).HasColumnName("read_at");
            entity.Property(e => e.ReadByUserId).HasColumnName("read_by_user_id");
            entity.Property(e => e.ReadByManagerId).HasColumnName("read_by_manager_id");
            entity.Property(e => e.IsEdited).HasColumnName("is_edited");
            entity.Property(e => e.EditedAt).HasColumnName("edited_at");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedByUserId).HasColumnName("deleted_by_user_id");
            entity.Property(e => e.DeletedByManagerId).HasColumnName("deleted_by_manager_id");
            entity.Property(e => e.MessageType).HasColumnName("message_type");
            entity.Property(e => e.AttachmentUrl).HasColumnName("attachment_url");
            entity.Property(e => e.AttachmentType).HasColumnName("attachment_type");
            entity.Property(e => e.ReplyToMessageId).HasColumnName("reply_to_message_id");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.Priority).HasColumnName("priority");
            entity.Property(e => e.IsInternal).HasColumnName("is_internal");
            entity.Property(e => e.IsPublic).HasColumnName("is_public");
            entity.Property(e => e.IsPinned).HasColumnName("is_pinned");
            entity.Property(e => e.PinnedAt).HasColumnName("pinned_at");
            entity.Property(e => e.PinOrder).HasColumnName("pin_order");
            entity.Property(e => e.PinnedBy).HasColumnName("pinned_by");
            entity.Property(e => e.PinReason).HasColumnName("pin_reason");
            entity.Property(e => e.IsArchived).HasColumnName("is_archived");
            entity.Property(e => e.ArchivedAt).HasColumnName("archived_at");
            entity.Property(e => e.ArchivedBy).HasColumnName("archived_by");
            entity.Property(e => e.ArchiveReason).HasColumnName("archive_reason");
            entity.Property(e => e.Settings).HasColumnName("settings");
        });

        // 配置 Support_Tickets 模型
        modelBuilder.Entity<Support_Tickets>(entity =>
        {
            entity.HasKey(e => e.TicketId).HasName("PK_Support_Tickets");
            entity.ToTable("Support_Tickets");
            entity.Property(e => e.TicketId).HasColumnName("ticket_id");
            entity.Property(e => e.TicketNumber).HasColumnName("ticket_number");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Subject).HasColumnName("subject");
            entity.Property(e => e.Description).HasColumnName("description");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.Priority).HasColumnName("priority");
            entity.Property(e => e.Category).HasColumnName("category");
            entity.Property(e => e.SubCategory).HasColumnName("sub_category");
            entity.Property(e => e.AssignedManagerId).HasColumnName("assigned_manager_id");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.ClosedAt).HasColumnName("closed_at");
            entity.Property(e => e.ClosedBy).HasColumnName("closed_by");
            entity.Property(e => e.CloseReason).HasColumnName("close_reason");
            entity.Property(e => e.Resolution).HasColumnName("resolution");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Tags).HasColumnName("tags");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.Settings).HasColumnName("settings");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
        });

        // 配置 Users 模型
        modelBuilder.Entity<Users>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK_Users");
            entity.ToTable("Users");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Username).HasColumnName("username");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.PasswordHash).HasColumnName("password_hash");
            entity.Property(e => e.FirstName).HasColumnName("first_name");
            entity.Property(e => e.LastName).HasColumnName("last_name");
            entity.Property(e => e.DisplayName).HasColumnName("display_name");
            entity.Property(e => e.AvatarUrl).HasColumnName("avatar_url");
            entity.Property(e => e.Phone).HasColumnName("phone");
            entity.Property(e => e.BirthDate).HasColumnName("birth_date");
            entity.Property(e => e.Gender).HasColumnName("gender");
            entity.Property(e => e.Country).HasColumnName("country");
            entity.Property(e => e.City).HasColumnName("city");
            entity.Property(e => e.Timezone).HasColumnName("timezone");
            entity.Property(e => e.Language).HasColumnName("language");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.IsEmailVerified).HasColumnName("is_email_verified");
            entity.Property(e => e.IsPhoneVerified).HasColumnName("is_phone_verified");
            entity.Property(e => e.EmailVerifiedAt).HasColumnName("email_verified_at");
            entity.Property(e => e.PhoneVerifiedAt).HasColumnName("phone_verified_at");
            entity.Property(e => e.LastLoginAt).HasColumnName("last_login_at");
            entity.Property(e => e.LastLoginIp).HasColumnName("last_login_ip");
            entity.Property(e => e.LoginCount).HasColumnName("login_count");
            entity.Property(e => e.FailedLoginCount).HasColumnName("failed_login_count");
            entity.Property(e => e.LockoutEnd).HasColumnName("lockout_end");
            entity.Property(e => e.TwoFactorEnabled).HasColumnName("two_factor_enabled");
            entity.Property(e => e.TwoFactorSecret).HasColumnName("two_factor_secret");
            entity.Property(e => e.RecoveryCodes).HasColumnName("recovery_codes");
            entity.Property(e => e.Preferences).HasColumnName("preferences");
            entity.Property(e => e.Settings).HasColumnName("settings");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
        });

        // 配置 UserSignInStats 模型
        modelBuilder.Entity<UserSignInStats>(entity =>
        {
            entity.HasKey(e => e.StatId).HasName("PK_UserSignInStats");
            entity.ToTable("UserSignInStats");
            entity.Property(e => e.StatId).HasColumnName("stat_id");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.SignInDate).HasColumnName("sign_in_date");
            entity.Property(e => e.SignInIp).HasColumnName("sign_in_ip");
            entity.Property(e => e.UserAgent).HasColumnName("user_agent");
            entity.Property(e => e.DeviceType).HasColumnName("device_type");
            entity.Property(e => e.Browser).HasColumnName("browser");
            entity.Property(e => e.OperatingSystem).HasColumnName("operating_system");
            entity.Property(e => e.Country).HasColumnName("country");
            entity.Property(e => e.City).HasColumnName("city");
            entity.Property(e => e.Region).HasColumnName("region");
            entity.Property(e => e.Latitude).HasColumnName("latitude");
            entity.Property(e => e.Longitude).HasColumnName("longitude");
            entity.Property(e => e.Timezone).HasColumnName("timezone");
            entity.Property(e => e.Language).HasColumnName("language");
            entity.Property(e => e.Referrer).HasColumnName("referrer");
            entity.Property(e => e.UtmSource).HasColumnName("utm_source");
            entity.Property(e => e.UtmMedium).HasColumnName("utm_medium");
            entity.Property(e => e.UtmCampaign).HasColumnName("utm_campaign");
            entity.Property(e => e.UtmTerm).HasColumnName("utm_term");
            entity.Property(e => e.UtmContent).HasColumnName("utm_content");
            entity.Property(e => e.SessionId).HasColumnName("session_id");
            entity.Property(e => e.SessionStart).HasColumnName("session_start");
            entity.Property(e => e.SessionEnd).HasColumnName("session_end");
            entity.Property(e => e.SessionDuration).HasColumnName("session_duration");
            entity.Property(e => e.PageViews).HasColumnName("page_views");
            entity.Property(e => e.Actions).HasColumnName("actions");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
        });

        // 配置 UserToken 模型
        modelBuilder.Entity<UserToken>(entity =>
        {
            entity.HasKey(e => e.TokenId).HasName("PK_UserTokens");
            entity.ToTable("UserTokens");
            entity.Property(e => e.TokenId).HasColumnName("token_id");
            entity.Property(e => e.UserId).HasColumnName("user_id");
            entity.Property(e => e.Token).HasColumnName("token");
            entity.Property(e => e.TokenType).HasColumnName("token_type");
            entity.Property(e => e.Purpose).HasColumnName("purpose");
            entity.Property(e => e.CreatedAt).HasColumnName("created_at");
            entity.Property(e => e.ExpiresAt).HasColumnName("expires_at");
            entity.Property(e => e.UsedAt).HasColumnName("used_at");
            entity.Property(e => e.UsedIp).HasColumnName("used_ip");
            entity.Property(e => e.UsedUserAgent).HasColumnName("used_user_agent");
            entity.Property(e => e.Status).HasColumnName("status");
            entity.Property(e => e.IsActive).HasColumnName("is_active");
            entity.Property(e => e.Notes).HasColumnName("notes");
            entity.Property(e => e.Metadata).HasColumnName("metadata");
            entity.Property(e => e.Settings).HasColumnName("settings");
            entity.Property(e => e.UpdatedAt).HasColumnName("updated_at");
            entity.Property(e => e.UpdatedBy).HasColumnName("updated_by");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.DeletedAt).HasColumnName("deleted_at");
            entity.Property(e => e.DeletedBy).HasColumnName("deleted_by");
            entity.Property(e => e.DeleteReason).HasColumnName("delete_reason");
        });

        modelBuilder.HasSequence("SeqOrderCode")
            .StartsAt(100000000001L)
            .HasMin(100000000001L)
            .HasMax(999999999999L);
        modelBuilder.HasSequence("SeqPaymentCode")
            .StartsAt(1000000000000001L)
            .HasMin(1000000000000001L)
            .HasMax(9999999999999999L);
        modelBuilder.HasSequence("SeqShipmentCode")
            .StartsAt(10000000000001L)
            .HasMin(10000000000001L)
            .HasMax(99999999999999L);

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
